package dev.cpp.block;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.simibubi.create.content.kinetics.base.RotatedPillarKineticBlock;
import com.simibubi.create.foundation.block.IBE;
import dev.cpp.blockentity.PneumaticCompressorBlockEntity;
import dev.cpp.pressure.api.IPressurePort;
import dev.cpp.pressure.core.PressureManager;
import dev.cpp.pressure.model.CompressorTier;
import dev.cpp.registry.ModRegistries;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Компрессор: вал по оси AXIS (вращение Create), воздушные порты на четырёх боковых гранях.
 * Класс Mk1–Mk3 задаёт Pmax (раздел 3.1). Реверс вала включает режим вакуумного насоса.
 */
public class PneumaticCompressorBlock extends RotatedPillarKineticBlock
        implements IBE<PneumaticCompressorBlockEntity>, IPressurePort {

    public static final MapCodec<PneumaticCompressorBlock> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            propertiesCodec(),
            Codec.intRange(1, 3).xmap(CompressorTier::byLevel, CompressorTier::getLevel)
                    .fieldOf("tier").forGetter(PneumaticCompressorBlock::tier)
    ).apply(instance, PneumaticCompressorBlock::new));

    private final CompressorTier tier;

    public PneumaticCompressorBlock(Properties properties, CompressorTier tier) {
        super(properties);
        this.tier = tier;
    }

    public CompressorTier tier() {
        return tier;
    }

    @Override
    protected MapCodec<PneumaticCompressorBlock> codec() {
        return CODEC;
    }

    @Override
    public boolean hasPressurePort(BlockState state, Direction face) {
        return face.getAxis() != state.getValue(AXIS);
    }

    @Override
    public Class<PneumaticCompressorBlockEntity> getBlockEntityClass() {
        return PneumaticCompressorBlockEntity.class;
    }

    @Override
    public BlockEntityType<? extends PneumaticCompressorBlockEntity> getBlockEntityType() {
        return ModRegistries.COMPRESSOR.get();
    }

    @Override
    protected void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
        if (!state.is(newState.getBlock()) && level instanceof ServerLevel serverLevel) {
            PressureManager.get(serverLevel).onRemoved(pos);
        }
        super.onRemove(state, level, pos, newState, movedByPiston);
    }
}
