package dev.cpp.pressure.api;

import dev.cpp.CppMod;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.neoforged.neoforge.capabilities.BlockCapability;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import org.jetbrains.annotations.Nullable;

/**
 * Объявление capability {@code cpp:pressure} и регистрация провайдеров.
 *
 * <p>Использование (во второй части, в классе мода):
 * <pre>
 * modBus.addListener((RegisterCapabilitiesEvent e) ->
 *         PressureCapabilities.register(e, ModBlockEntities.PRESSURE_PIPE.get()));
 * </pre>
 */
public final class PressureCapabilities {
    private PressureCapabilities() {}

    public static final BlockCapability<IPressureHandler, @Nullable Direction> PRESSURE =
            BlockCapability.createSided(CppMod.id("pressure"), IPressureHandler.class);

    /** Регистрирует BlockEntity-тип как источник capability: сам BE и есть обработчик для любой грани. */
    public static <T extends BlockEntity & IPressureHandler> void register(
            RegisterCapabilitiesEvent event, BlockEntityType<T> type) {
        event.registerBlockEntity(PRESSURE, type, (be, side) -> be);
    }
}
