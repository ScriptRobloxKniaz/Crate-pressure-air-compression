package dev.cpp.pressure.core;

/**
 * Значения по умолчанию из раздела 11 «Конфиг». В Milestone 1 это константы;
 * привязка к ModConfigSpec (config/cpp-common.toml) делается позже, ключи имён совпадают.
 */
public final class PressureConstants {
    private PressureConstants() {}

    /** network.recalcIntervalTicks */
    public static final int RECALC_INTERVAL_TICKS = 5;
    /** network.traversalBudgetPerTick */
    public static final int BFS_BUDGET_PER_TICK = 256;
    /** network.maxBlocksPerNetwork */
    public static final int MAX_BLOCKS_PER_NETWORK = 1500;
    /** network.pressureMax */
    public static final float PRESSURE_MAX = 1000.0f;
    /** network.vacuumMin */
    public static final float VACUUM_MIN = -100.0f;
    /** equalizeTicks из A.3.2 (только для отображения) */
    public static final int EQUALIZE_TICKS = 10;
    /** Длина кольца pHist: 9 значений по 5 тиков, элемент «8 шагов назад» = 2 секунды */
    public static final int HISTORY_SIZE = 9;

    /** burst.terrainDamage: OFF — без взрыва, только труба и отбрасывание; DROPS — урон существам, блоки целы,
     *  разрушенные трубы выпадают предметами; FULL — обычный взрыв с разрушением блоков. */
    public enum TerrainDamage { OFF, DROPS, FULL }

    public static final TerrainDamage TERRAIN_DAMAGE = TerrainDamage.DROPS;
    /** Радиус облака воздуха при взрыве, блоков. */
    public static final double BURST_CLOUD_RADIUS = 6.0;
}
