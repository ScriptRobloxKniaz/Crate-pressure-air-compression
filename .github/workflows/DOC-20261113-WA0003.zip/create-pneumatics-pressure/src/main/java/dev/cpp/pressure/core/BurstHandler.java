package dev.cpp.pressure.core;

import dev.cpp.pressure.api.IPressureHandler;
import dev.cpp.pressure.model.BurstModel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Мировые эффекты перегрузки (раздел 2.4): взрыв самого слабого узла, цепной разрыв изношенных соседей,
 * «облако воздуха» с отбрасыванием и схлопывание от вакуума. Расчёты берёт у {@link BurstModel}.
 */
public final class BurstHandler {
    private BurstHandler() {}

    /** Предупреждение во время фазы перегрузки: скрип и дымок у слабого узла. */
    public static void warn(ServerLevel level, PressureNetwork net) {
        BlockPos weakest = net.getWeakest();
        if (weakest == null) {
            return;
        }
        double x = weakest.getX() + 0.5, y = weakest.getY() + 0.5, z = weakest.getZ() + 0.5;
        level.sendParticles(ParticleTypes.SMOKE, x, y, z, 3, 0.25, 0.25, 0.25, 0.01);
        if (net.getOverloadTicks() % 20 < 5) {
            float pitch = 0.6f + 0.8f * (net.getOverloadTicks() / (float) BurstModel.OVERLOAD_TICKS);
            level.playSound(null, weakest, SoundEvents.CHAIN_HIT, SoundSource.BLOCKS, 0.8f, pitch);
        }
    }

    /** Взрыв слабейшего узла сети. */
    public static void burst(ServerLevel level, PressureManager manager, PressureNetwork net) {
        BlockPos origin = net.getWeakest();
        if (origin == null) {
            return;
        }
        IPressureHandler handler = manager.handlerAt(origin);
        float pressure = net.getPressure();
        float limit = handler != null ? handler.getLimit() : net.getMinBurstLimit();
        float cap = handler != null ? handler.getBurstPowerCap() : BurstModel.CAP_PIPE;
        float power = BurstModel.power(pressure, limit, cap);
        Vec3 center = Vec3.atCenterOf(origin);

        switch (PressureConstants.TERRAIN_DAMAGE) {
            case OFF -> { /* без взрыва: только облако воздуха и сама труба */ }
            case DROPS -> level.explode(null, center.x, center.y, center.z, power, false, Level.ExplosionInteraction.NONE);
            case FULL -> level.explode(null, center.x, center.y, center.z, power, false, Level.ExplosionInteraction.BLOCK);
        }
        level.destroyBlock(origin, true);
        level.sendParticles(ParticleTypes.CLOUD, center.x, center.y, center.z, 40, 0.6, 0.6, 0.6, 0.15);
        airBlast(level, center, pressure);
        chain(level, manager, net, origin);
    }

    /** Схлопывание от вакуума: деталь ломается без взрыва и без урона. */
    public static void implode(ServerLevel level, PressureNetwork net) {
        BlockPos origin = net.getWeakest();
        if (origin == null) {
            return;
        }
        level.destroyBlock(origin, true);
        level.sendParticles(ParticleTypes.POOF, origin.getX() + 0.5, origin.getY() + 0.5, origin.getZ() + 0.5,
                15, 0.3, 0.3, 0.3, 0.02);
        level.playSound(null, origin, SoundEvents.ANVIL_LAND, SoundSource.BLOCKS, 0.6f, 0.7f);
    }

    /** Облако воздуха: отбрасывание существ в радиусе 6 блоков, сила растёт с давлением, урона нет. */
    private static void airBlast(ServerLevel level, Vec3 center, float pressure) {
        double radius = PressureConstants.BURST_CLOUD_RADIUS;
        double strength = 0.3 + Math.max(0.0f, pressure) / 1000.0;
        AABB box = new AABB(center, center).inflate(radius);
        for (Entity entity : level.getEntities((Entity) null, box, e -> !e.isSpectator())) {
            Vec3 away = entity.position().add(0.0, entity.getBbHeight() / 2.0, 0.0).subtract(center);
            double dist = Math.max(0.5, away.length());
            if (dist > radius) {
                continue;
            }
            double falloff = 1.0 - dist / radius;
            Vec3 push = away.normalize().scale(strength * falloff * 1.5).add(0.0, 0.1 * falloff, 0.0);
            entity.setDeltaMovement(entity.getDeltaMovement().add(push));
            entity.hurtMarked = true;
        }
    }

    /**
     * Цепной разрыв (2.4): от места взрыва по графу сети до 12 сегментов; изношенный (> 50 %) узел на расстоянии
     * d лопается с вероятностью 0.5^(d/2). Разрушенные трубы выпадают предметами.
     */
    private static void chain(ServerLevel level, PressureManager manager, PressureNetwork net, BlockPos origin) {
        Map<BlockPos, Integer> distance = new HashMap<>();
        Deque<BlockPos> queue = new ArrayDeque<>();
        List<BlockPos> candidates = new ArrayList<>();
        distance.put(origin, 0);
        queue.add(origin);
        while (!queue.isEmpty()) {
            BlockPos pos = queue.poll();
            int d = distance.get(pos);
            if (d >= BurstModel.CHAIN_LIMIT) {
                continue;
            }
            for (Direction dir : Direction.values()) {
                BlockPos next = pos.relative(dir);
                if (distance.containsKey(next) || !net.contains(next) || !manager.connected(pos, dir)) {
                    continue;
                }
                distance.put(next, d + 1);
                queue.add(next);
                candidates.add(next);
            }
        }
        for (BlockPos pos : candidates) {
            IPressureHandler h = manager.handlerAt(pos);
            if (h == null || h.getWear() <= 50.0f) {
                continue;
            }
            if (level.random.nextDouble() < BurstModel.chainProbability(distance.get(pos))) {
                level.destroyBlock(pos, true);
                level.sendParticles(ParticleTypes.CLOUD, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5,
                        8, 0.3, 0.3, 0.3, 0.05);
            }
        }
    }
}
