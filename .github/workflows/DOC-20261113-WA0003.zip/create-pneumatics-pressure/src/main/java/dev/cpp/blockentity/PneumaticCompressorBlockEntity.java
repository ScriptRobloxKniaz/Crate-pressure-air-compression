package dev.cpp.blockentity;

import com.simibubi.create.content.kinetics.base.KineticBlockEntity;
import dev.cpp.block.PneumaticCompressorBlock;
import dev.cpp.goggles.PressureGoggleLines;
import dev.cpp.pressure.api.IPressureHandler;
import dev.cpp.pressure.api.IPressureMachine;
import dev.cpp.pressure.core.AirDensity;
import dev.cpp.pressure.core.PipeTier;
import dev.cpp.pressure.core.PressureConstants;
import dev.cpp.pressure.core.PressureManager;
import dev.cpp.pressure.model.BurstModel;
import dev.cpp.pressure.model.CompressorModel;
import dev.cpp.pressure.model.CompressorTier;
import dev.cpp.registry.ModRegistries;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;

import java.util.List;

/**
 * Компрессор (Kinetic → Pressure). Физика в {@link CompressorModel}; здесь только привязка к Create и сети давления.
 * Охлаждение в M2 — временное: соседний блок воды даёт −1.5 °C/сек (позже заменится водой по трубам Create).
 */
public class PneumaticCompressorBlockEntity extends KineticBlockEntity implements IPressureHandler, IPressureMachine {

    private static final float WATER_COOLING = 1.5f;
    private static final int VOLUME = 2;

    private final CompressorModel model = new CompressorModel();
    private final PressureNodeState node = new PressureNodeState();
    private float lastPressure;
    private float lastAppliedStress = -1.0f;
    private float syncedTemperature = CompressorModel.AMBIENT;
    private boolean exploded;

    public PneumaticCompressorBlockEntity(BlockPos pos, BlockState state) {
        this(ModRegistries.COMPRESSOR.get(), pos, state);
    }

    public PneumaticCompressorBlockEntity(BlockEntityType<?> type, BlockPos pos, BlockState state) {
        super(type, pos, state);
    }

    public CompressorTier tier() {
        return getBlockState().getBlock() instanceof PneumaticCompressorBlock block ? block.tier() : CompressorTier.MK1;
    }

    /** Прочность компрессора как у трубы соответствующего класса: Mk1 — медь, Mk2 — железо, Mk3 — незерит. */
    private PipeTier limitClass() {
        return switch (tier()) {
            case MK1 -> PipeTier.COPPER;
            case MK2 -> PipeTier.IRON;
            case MK3 -> PipeTier.NETHERITE;
        };
    }

    // ------------------------------------------------------------------ жизненный цикл

    @Override
    public void initialize() {
        super.initialize();
        if (level instanceof ServerLevel serverLevel) {
            PressureManager.get(serverLevel).onPlaced(worldPosition);
        }
    }

    // ------------------------------------------------------------------ стресс (Create)

    /** Нагрузка на вал, су на 1 RPM: 6 × (1 − 0.5·P/Pmax). */
    @Override
    public float calculateStressApplied() {
        float impact = CompressorModel.stressPerRpm(lastPressure, tier(), getSpeed() < 0.0f);
        this.lastStressApplied = impact;
        return impact;
    }

    private void refreshStress() {
        float impact = CompressorModel.stressPerRpm(lastPressure, tier(), getSpeed() < 0.0f);
        if (Math.abs(impact - lastAppliedStress) < 0.1f) {
            return;
        }
        lastAppliedStress = impact;
        if (hasNetwork()) {
            getOrCreateNetwork().updateStressFor(this, calculateStressApplied());
        }
    }

    // ------------------------------------------------------------------ IPressureMachine

    @Override
    public double produce(float p0, int dtTicks) {
        if (level == null) {
            return 0.0;
        }
        lastPressure = p0;
        return model.produce(getSpeed(), AirDensity.at(level, worldPosition), p0, tier(), dtTicks);
    }

    @Override
    public void postStep(float p1, int dtTicks) {
        lastPressure = p1;
        float cooling = hasAdjacentWater() ? WATER_COOLING : 0.0f;
        model.updateHeat(getSpeed(), p1, CompressorModel.AMBIENT, cooling, dtTicks);
        refreshStress();
        float t = model.getTemperature();
        if (Math.abs(t - syncedTemperature) >= 5.0f) {
            syncedTemperature = t;
            sendData();
        }
        if (model.isBurstTemperature() && !exploded && level instanceof ServerLevel serverLevel) {
            exploded = true; // 200 °C: взрыв силой 2.0 (раздел 3.1); блок исчезнет на ближайшем тике
            serverLevel.explode(null, worldPosition.getX() + 0.5, worldPosition.getY() + 0.5,
                    worldPosition.getZ() + 0.5, BurstModel.CAP_COMPRESSOR, false,
                    PressureConstants.TERRAIN_DAMAGE == PressureConstants.TerrainDamage.FULL
                            ? Level.ExplosionInteraction.BLOCK : Level.ExplosionInteraction.NONE);
            serverLevel.destroyBlock(worldPosition, true);
        }
    }

    private boolean hasAdjacentWater() {
        if (level == null) {
            return false;
        }
        for (Direction dir : Direction.values()) {
            if (level.getFluidState(worldPosition.relative(dir)).is(FluidTags.WATER)) {
                return true;
            }
        }
        return false;
    }

    // ------------------------------------------------------------------ NBT и синхронизация

    @Override
    protected void write(CompoundTag compound, HolderLookup.Provider registries, boolean clientPacket) {
        super.write(compound, registries, clientPacket);
        node.write(compound, level, worldPosition);
        compound.putFloat("Temperature", model.getTemperature());
    }

    @Override
    protected void read(CompoundTag compound, HolderLookup.Provider registries, boolean clientPacket) {
        super.read(compound, registries, clientPacket);
        node.read(compound);
        float t = compound.contains("Temperature") ? compound.getFloat("Temperature") : CompressorModel.AMBIENT;
        model.setTemperature(t);
        syncedTemperature = t;
    }

    // ------------------------------------------------------------------ очки Create

    @Override
    public boolean addToGoggleTooltip(List<Component> tooltip, boolean isPlayerSneaking) {
        super.addToGoggleTooltip(tooltip, isPlayerSneaking);
        PressureGoggleLines.add(tooltip, worldPosition, this, isPlayerSneaking, limitClass().getWorkingMax());

        float t = model.getTemperature();
        ChatFormatting color = t >= CompressorModel.WARN_TEMP ? ChatFormatting.RED
                : t >= 100.0f ? ChatFormatting.GOLD : ChatFormatting.GREEN;
        tooltip.add(PressureGoggleLines.line(Component.translatable("cpp.goggles.temperature",
                PressureGoggleLines.fmt("%.0f", t)).withStyle(color)));
        tooltip.add(PressureGoggleLines.line(Component.translatable(
                getSpeed() < 0.0f ? "cpp.goggles.mode.vacuum" : "cpp.goggles.mode.pressure")
                .withStyle(ChatFormatting.GRAY)));
        if (model.isOverheating()) {
            tooltip.add(PressureGoggleLines.line(Component.translatable("cpp.goggles.throttled")
                    .withStyle(ChatFormatting.RED)));
        }
        return true;
    }

    // ------------------------------------------------------------------ IPressureHandler

    @Override public int getVolume() { return VOLUME; }
    @Override public float getLimit() { return limitClass().getBurstLimit(); }
    @Override public float getWorkingMax() { return limitClass().getWorkingMax(); }
    @Override public float getBurstPowerCap() { return BurstModel.CAP_COMPRESSOR; }
    @Override public float getVacuumLimit() { return limitClass().getVacuumLimit(); }

    @Override
    public boolean canConnect(Direction face) {
        BlockState state = getBlockState();
        return state.getBlock() instanceof PneumaticCompressorBlock block && block.hasPressurePort(state, face);
    }

    @Override public int getSealLevel(Direction face) { return node.getSeal(face); }

    @Override
    public void setSealLevel(Direction face, int level) {
        node.setSeal(face, level);
        setChanged();
        notifyLeakChange();
    }

    @Override public boolean isOpenPort(Direction face) { return false; }

    @Override
    public void applyWear(float amount) {
        node.applyWear(amount);
        setChanged();
        notifyLeakChange();
    }

    private void notifyLeakChange() {
        if (level instanceof ServerLevel serverLevel) {
            PressureManager.get(serverLevel).markNodeDirty(worldPosition);
        }
    }

    @Override public double getSavedMass() { return node.getMass(); }
    @Override public float getWear() { return node.getWear(); }
    @Override public float getCondensate() { return node.getCondensate(); }
}
