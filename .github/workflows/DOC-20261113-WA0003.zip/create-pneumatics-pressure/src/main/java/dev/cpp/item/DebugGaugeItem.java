package dev.cpp.item;

import dev.cpp.network.ProbeRequest;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * Отладочный манометр. ПКМ по блоку — запрос данных сети; Shift+ПКМ — то же, но оператор дополнительно
 * закачивает +10 PSI (пока нет компрессора). Ответ приходит пакетом ProbeResult и печатается в чат.
 */
public class DebugGaugeItem extends Item {

    public DebugGaugeItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        if (level.isClientSide) {
            boolean inject = context.getPlayer() != null && context.getPlayer().isShiftKeyDown();
            PacketDistributor.sendToServer(new ProbeRequest(context.getClickedPos(), inject, true));
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
