package dev.cpp.pressure.core;

import com.mojang.serialization.Codec;
import net.minecraft.util.StringRepresentable;

/**
 * Классы труб из таблицы 2.2. В Milestone 1 значения зашиты в enum;
 * позже их заменит PressureTierRegistry, читающий data/cpp/pressure_tiers/*.json (A.6).
 */
public enum PipeTier implements StringRepresentable {
    COPPER("copper", 120f, 160f, -30f, 1),
    IRON("iron", 350f, 450f, -60f, 1),
    DIAMOND("diamond", 650f, 800f, -90f, 1),
    NETHERITE("netherite", 900f, 1000f, -100f, 1);

    public static final Codec<PipeTier> CODEC = StringRepresentable.fromEnum(PipeTier::values);

    private final String name;
    private final float workingMax;
    private final float burstLimit;
    private final float vacuumLimit;
    private final int volume;

    PipeTier(String name, float workingMax, float burstLimit, float vacuumLimit, int volume) {
        this.name = name;
        this.workingMax = workingMax;
        this.burstLimit = burstLimit;
        this.vacuumLimit = vacuumLimit;
        this.volume = volume;
    }

    public float getWorkingMax() { return workingMax; }
    public float getBurstLimit() { return burstLimit; }
    public float getVacuumLimit() { return vacuumLimit; }
    public int getVolume() { return volume; }

    public static PipeTier byOrdinal(int ordinal) {
        PipeTier[] all = values();
        return all[Math.floorMod(ordinal, all.length)];
    }

    @Override
    public String getSerializedName() {
        return name;
    }
}
