package dev.cpp.pressure.model;

/** Классы компрессора. Pmax — давление, при котором производительность падает до нуля (раздел 3.1). */
public enum CompressorTier {
    MK1(1, 150f),
    MK2(2, 400f),
    MK3(3, 1000f);

    private final int level;
    private final float pmax;

    CompressorTier(int level, float pmax) {
        this.level = level;
        this.pmax = pmax;
    }

    public int getLevel() { return level; }
    public float getPmax() { return pmax; }

    public static CompressorTier byLevel(int level) {
        for (CompressorTier t : values()) {
            if (t.level == level) {
                return t;
            }
        }
        return MK1;
    }
}
