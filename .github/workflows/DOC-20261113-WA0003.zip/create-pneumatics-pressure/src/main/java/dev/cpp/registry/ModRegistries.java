package dev.cpp.registry;

import dev.cpp.CppMod;
import dev.cpp.block.PneumaticCompressorBlock;
import dev.cpp.block.PneumaticMotorBlock;
import dev.cpp.block.PressurePipeBlock;
import dev.cpp.blockentity.PneumaticCompressorBlockEntity;
import dev.cpp.blockentity.PneumaticMotorBlockEntity;
import dev.cpp.pressure.model.CompressorTier;
import dev.cpp.blockentity.PressureBlockEntity;
import dev.cpp.item.DebugGaugeItem;
import dev.cpp.item.PneumaticWrenchItem;
import dev.cpp.item.PortPlugItem;
import dev.cpp.pressure.core.PipeTier;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.EnumMap;
import java.util.Map;

/** Регистры: четыре трубы, компрессоры Mk1–Mk3, пневматический двигатель, типы BlockEntity и отладочный манометр. */
public final class ModRegistries {
    private ModRegistries() {}

    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(CppMod.MODID);
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(CppMod.MODID);
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, CppMod.MODID);

    public static final Map<PipeTier, DeferredBlock<PressurePipeBlock>> PIPES = new EnumMap<>(PipeTier.class);

    static {
        for (PipeTier tier : PipeTier.values()) {
            DeferredBlock<PressurePipeBlock> block = BLOCKS.registerBlock(
                    tier.getSerializedName() + "_pipe",
                    props -> new PressurePipeBlock(props, tier),
                    BlockBehaviour.Properties.of()
                            .mapColor(MapColor.METAL)
                            .strength(2.0f, 6.0f)
                            .sound(SoundType.COPPER)
                            .noOcclusion());
            ITEMS.registerSimpleBlockItem(block);
            PIPES.put(tier, block);
        }
    }

    public static final Map<CompressorTier, DeferredBlock<PneumaticCompressorBlock>> COMPRESSORS = new EnumMap<>(CompressorTier.class);

    static {
        for (CompressorTier tier : CompressorTier.values()) {
            DeferredBlock<PneumaticCompressorBlock> block = BLOCKS.registerBlock(
                    "pneumatic_compressor_mk" + tier.getLevel(),
                    props -> new PneumaticCompressorBlock(props, tier),
                    BlockBehaviour.Properties.of().mapColor(MapColor.METAL).strength(3.0f, 6.0f).sound(SoundType.METAL));
            ITEMS.registerSimpleBlockItem(block);
            COMPRESSORS.put(tier, block);
        }
    }

    public static final DeferredBlock<PneumaticMotorBlock> MOTOR_BLOCK = BLOCKS.registerBlock(
            "pneumatic_motor", PneumaticMotorBlock::new,
            BlockBehaviour.Properties.of().mapColor(MapColor.METAL).strength(3.0f, 6.0f).sound(SoundType.METAL));

    static {
        ITEMS.registerSimpleBlockItem(MOTOR_BLOCK);
    }

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<PneumaticCompressorBlockEntity>> COMPRESSOR =
            BLOCK_ENTITIES.register("pneumatic_compressor", () -> BlockEntityType.Builder.of(
                    PneumaticCompressorBlockEntity::new,
                    COMPRESSORS.values().stream().map(DeferredBlock::get).toArray(Block[]::new)).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<PneumaticMotorBlockEntity>> MOTOR =
            BLOCK_ENTITIES.register("pneumatic_motor", () -> BlockEntityType.Builder.of(
                    PneumaticMotorBlockEntity::new, MOTOR_BLOCK.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<PressureBlockEntity>> PRESSURE_NODE =
            BLOCK_ENTITIES.register("pressure_node", () -> BlockEntityType.Builder.of(
                    PressureBlockEntity::new,
                    PIPES.values().stream().map(DeferredBlock::get).toArray(Block[]::new)).build(null));

    public static final DeferredItem<DebugGaugeItem> DEBUG_GAUGE =
            ITEMS.registerItem("debug_gauge", DebugGaugeItem::new, new Item.Properties().stacksTo(1));

    public static final DeferredItem<PneumaticWrenchItem> PNEUMATIC_WRENCH =
            ITEMS.registerItem("pneumatic_wrench", PneumaticWrenchItem::new, new Item.Properties().stacksTo(1).durability(256));

    public static final DeferredItem<PortPlugItem> PORT_PLUG =
            ITEMS.registerItem("port_plug", PortPlugItem::new, new Item.Properties());

    public static void register(IEventBus modBus) {
        BLOCKS.register(modBus);
        ITEMS.register(modBus);
        BLOCK_ENTITIES.register(modBus);
        modBus.addListener(ModRegistries::addToCreativeTabs);
    }

    private static void addToCreativeTabs(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.REDSTONE_BLOCKS) {
            PIPES.values().forEach(event::accept);
            COMPRESSORS.values().forEach(event::accept);
            event.accept(MOTOR_BLOCK);
        }
        if (event.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
            event.accept(DEBUG_GAUGE);
            event.accept(PNEUMATIC_WRENCH);
            event.accept(PORT_PLUG);
        }
    }
}
