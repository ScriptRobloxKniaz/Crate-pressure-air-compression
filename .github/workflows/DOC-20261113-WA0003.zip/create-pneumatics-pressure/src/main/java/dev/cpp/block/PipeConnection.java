package dev.cpp.block;

import net.minecraft.util.StringRepresentable;

/** Состояние грани трубы (A.1: connected_* = none | pipe | port | plug). */
public enum PipeConnection implements StringRepresentable {
    NONE("none"),
    PIPE("pipe"),
    PORT("port"),
    PLUG("plug");

    private final String name;

    PipeConnection(String name) {
        this.name = name;
    }

    /** Грань участвует в графе сети: соединена с соседним узлом. PORT — открытый конец без соседа (большая утечка). */
    public boolean isConnected() {
        return this == PIPE;
    }

    @Override
    public String getSerializedName() {
        return name;
    }
}
