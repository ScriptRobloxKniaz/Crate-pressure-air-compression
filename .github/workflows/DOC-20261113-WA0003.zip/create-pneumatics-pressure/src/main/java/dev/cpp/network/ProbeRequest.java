package dev.cpp.network;

import com.simibubi.create.content.equipment.goggles.GogglesItem;
import dev.cpp.CppMod;
import dev.cpp.item.DebugGaugeItem;
import dev.cpp.pressure.api.IPressureHandler;
import dev.cpp.pressure.api.PressureCapabilities;
import dev.cpp.pressure.core.PressureManager;
import dev.cpp.pressure.core.PressureNetwork;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.handling.IPayloadContext;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Клиент → сервер: «покажи данные сети в этой точке» (A.4).
 *
 * <ul>
 *   <li>{@code chat = true} — запрос от манометра (нужен предмет в руке), ответ печатается в чат;</li>
 *   <li>{@code chat = false} — тихий запрос от очков Create, ответ только пополняет клиентский кэш оверлея;</li>
 *   <li>{@code inject} — отладка M1: оператор добавляет +10 PSI.</li>
 * </ul>
 */
public record ProbeRequest(BlockPos pos, boolean inject, boolean chat) implements CustomPacketPayload {

    public static final Type<ProbeRequest> TYPE = new Type<>(CppMod.id("probe_request"));

    public static final StreamCodec<RegistryFriendlyByteBuf, ProbeRequest> STREAM_CODEC =
            StreamCodec.composite(
                    BlockPos.STREAM_CODEC, ProbeRequest::pos,
                    ByteBufCodecs.BOOL, ProbeRequest::inject,
                    ByteBufCodecs.BOOL, ProbeRequest::chat,
                    ProbeRequest::new);

    /** Минимальный интервал между тихими запросами одного игрока, тики (клиент шлёт раз в 10). */
    private static final int SILENT_COOLDOWN_TICKS = 5;
    private static final Map<UUID, Integer> LAST_SILENT = new HashMap<>();

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(ProbeRequest request, IPayloadContext context) {
        if (!(context.player() instanceof ServerPlayer player)) {
            return;
        }
        boolean holdsGauge = player.getMainHandItem().getItem() instanceof DebugGaugeItem
                || player.getOffhandItem().getItem() instanceof DebugGaugeItem;
        if (request.chat() || request.inject()) {
            if (!holdsGauge) {
                return;
            }
        } else {
            if (!holdsGauge && !GogglesItem.isWearingGoggles(player)) {
                return;
            }
            int last = LAST_SILENT.getOrDefault(player.getUUID(), -SILENT_COOLDOWN_TICKS);
            if (player.tickCount - last < SILENT_COOLDOWN_TICKS) {
                return;
            }
            LAST_SILENT.put(player.getUUID(), player.tickCount);
        }
        if (player.distanceToSqr(Vec3.atCenterOf(request.pos())) > 36.0) {
            return;
        }
        ServerLevel level = player.serverLevel();
        if (!level.isLoaded(request.pos())) {
            return;
        }

        PressureNetwork net = PressureManager.get(level).getNetworkAt(request.pos());
        if (net != null && request.inject() && player.hasPermissions(2)) {
            net.queueDelta(10.0 * net.getVolume() / 100.0); // +10 PSI на ближайшем шаге
            net.requestStep();
        }
        IPressureHandler node = level.getCapability(PressureCapabilities.PRESSURE, request.pos(), null);
        PacketDistributor.sendToPlayer(player, ProbeResult.of(request.pos(), net, node, request.chat()));
    }
}
