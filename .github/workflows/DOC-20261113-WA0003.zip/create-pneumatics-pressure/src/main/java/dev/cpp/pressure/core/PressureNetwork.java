package dev.cpp.pressure.core;

import dev.cpp.pressure.api.IPressureMachine;
import dev.cpp.pressure.model.BurstModel;
import dev.cpp.pressure.model.CondensateModel;
import dev.cpp.pressure.model.LeakModel;
import it.unimi.dsi.fastutil.longs.LongIterator;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import it.unimi.dsi.fastutil.longs.LongSet;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.FloatTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.world.level.ChunkPos;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Сеть давления (A.3). Масса M хранится со знаком (относительно атмосферы),
 * давление {@code P = 100 × M / V}. Авторитетная масса лежит здесь; поле mass в BlockEntity —
 * лишь снимок доли узла для записи на диск.
 */
public final class PressureNetwork {

    public enum State { ACTIVE, SLEEPING, REBUILDING }

    private final UUID id;
    private double mass;
    private int volume;
    private final Set<BlockPos> blocks = new HashSet<>();
    private final Map<BlockPos, Integer> nodeVolumes = new HashMap<>();
    /** Узлы-машины (производят или потребляют воздух); обходятся на каждом шаге сети. */
    private final Set<BlockPos> machines = new HashSet<>();
    private float cachedPressure;
    private State state = State.ACTIVE;

    /** Вклады машин, накопленные между шагами (ед. массы). Применяется в recalculate(). */
    private double pendingDelta;
    private float temperature = 20.0f;
    private @Nullable UUID owner;

    /** Чанки, в которых есть узлы, но они сейчас не загружены (A.3.4). */
    private final LongSet unloadedChunks = new LongOpenHashSet();

    /** Кольцо истории давления: каждые 5 тиков одно значение. */
    private final float[] pHist = new float[PressureConstants.HISTORY_SIZE];
    private int histHead;
    private boolean histValid;

    /** Оставшиеся тики плавного отображения после слияния (физика при этом мгновенная). */
    private int equalizeTicks;
    private long lastStepTick;
    private boolean forceStep;

    // --- кэши и результаты шагов 3, 5, 6 (A.2) ---
    private double leakSum;
    private float minBurstLimit = Float.MAX_VALUE;
    private float minVacuumLimit = -Float.MAX_VALUE;
    private @Nullable BlockPos weakest;
    private boolean cachesDirty = true;
    private int overloadTicks;
    private boolean burstRequested;
    private boolean implodeRequested;
    private float condensateAmount;
    private int condensateCooldown;
    private boolean pressurizedFlag;

    public PressureNetwork(UUID id) {
        this.id = id;
    }

    // ------------------------------------------------------------------ узлы

    /** Добавляет узел. Возвращает false, если он уже есть. */
    public boolean addNode(BlockPos pos, int nodeVolume, double nodeMass) {
        return addNode(pos, nodeVolume, nodeMass, false);
    }

    public boolean addNode(BlockPos pos, int nodeVolume, double nodeMass, boolean machine) {
        BlockPos key = pos.immutable();
        if (!blocks.add(key)) {
            return false;
        }
        if (machine) {
            machines.add(key);
        }
        cachesDirty = true;
        nodeVolumes.put(key, nodeVolume);
        volume += nodeVolume;
        mass += nodeMass;
        refreshPressure();
        return true;
    }

    /**
     * Удаляет узел и возвращает потерянную массу: {@code M × V_узла / V} уходит в воздух (A.3.3).
     * Давление оставшейся части не меняется.
     */
    public double removeNode(BlockPos pos) {
        Integer v = nodeVolumes.remove(pos);
        if (v == null) {
            return 0.0;
        }
        blocks.remove(pos);
        machines.remove(pos);
        double lost = volume > 0 ? mass * v / volume : 0.0;
        mass -= lost;
        volume -= v;
        if (blocks.isEmpty()) {
            mass = 0.0;
            volume = 0;
        }
        pruneUnloadedChunks();
        cachesDirty = true;
        refreshPressure();
        return lost;
    }

    public boolean contains(BlockPos pos) {
        return blocks.contains(pos);
    }

    public boolean isEmpty() {
        return blocks.isEmpty();
    }

    public int getBlockCount() {
        return blocks.size();
    }

    public Set<BlockPos> getMachines() {
        return Collections.unmodifiableSet(machines);
    }

    public Set<BlockPos> getBlocks() {
        return Collections.unmodifiableSet(blocks);
    }

    public int getNodeVolume(BlockPos pos) {
        return nodeVolumes.getOrDefault(pos, 0);
    }

    /** Доля массы узла: {@code M × V_узла / V}. */
    public double getNodeMassShare(BlockPos pos) {
        Integer v = nodeVolumes.get(pos);
        if (v == null || volume <= 0) {
            return 0.0;
        }
        return mass * v / volume;
    }

    // ------------------------------------------------------------------ физика

    /** Живое давление по формуле P = 100 × M / V. */
    public double computePressure() {
        return volume > 0 ? 100.0 * mass / volume : 0.0;
    }

    /** Кэшированное давление, обновляется в recalculate(); его читают машины между шагами. */
    public float getPressure() {
        return cachedPressure;
    }

    /** Сеть кладёт вклад машины (+ нагнетание, − расход) в накопитель; применяется на ближайшем шаге. */
    public void queueDelta(double deltaMass) {
        pendingDelta += deltaMass;
    }

    /** Шаг сети без машин (оставлен для совместимости с Milestone 1). */
    public void recalculate(int dtTicks) {
        recalculate(dtTicks, List.of());
    }

    /**
     * Шаг сети в порядке A.2: 1 нагнетание → 2 расход → 3 утечка (Milestone 3) → 4 нагрев → 5 перегрузка (M3)
     * → 6 конденсат (M3) → 7 шум (M3). P₀ — снимок на начало шага, поэтому порядок машин не влияет на результат.
     * Если потребителям не хватает воздуха, они получают пропорциональную долю («голодание»).
     *
     * @param dtTicks сколько тиков прошло с прошлого шага (1..5)
     */
    public void recalculate(int dtTicks, Collection<? extends IPressureMachine> activeMachines) {
        if (volume <= 0) {
            mass = 0.0;
            pendingDelta = 0.0;
            cachedPressure = 0.0f;
            return;
        }
        float p0 = (float) computePressure();

        // 1–2: нагнетание и расход
        double produced = 0.0;
        double wanted = 0.0;
        for (IPressureMachine m : activeMachines) {
            produced += m.produce(p0, dtTicks);
        }
        for (IPressureMachine m : activeMachines) {
            wanted += Math.max(0.0, m.demand(p0, dtTicks));
        }
        double available = Math.max(0.0, mass + pendingDelta + produced);
        double fraction = wanted <= 1.0e-12 ? 1.0 : Math.min(1.0, available / wanted);
        for (IPressureMachine m : activeMachines) {
            m.onSupplied(fraction);
        }
        mass += pendingDelta + produced - wanted * fraction;
        pendingDelta = 0.0;

        // 3: утечка (по P₀, одной суммой на всю сеть)
        mass = LeakModel.applyLoss(mass, LeakModel.massLoss(leakSum, p0, dtTicks));

        double minMass = PressureConstants.VACUUM_MIN * volume / 100.0;
        if (mass < minMass) {
            mass = minMass;
        }
        cachedPressure = (float) computePressure();
        pushHistory(cachedPressure);

        // 4: нагрев по итоговому P₁
        for (IPressureMachine m : activeMachines) {
            m.postStep(cachedPressure, dtTicks);
        }

        // 5: перегрузка (счётчик на сеть; рвётся самый слабый узел)
        boolean over = BurstModel.isOverloaded(cachedPressure, minBurstLimit, minVacuumLimit);
        overloadTicks = BurstModel.updateOverload(overloadTicks, over, dtTicks);
        if (overloadTicks >= BurstModel.OVERLOAD_TICKS) {
            if (cachedPressure < minVacuumLimit) {
                implodeRequested = true;
            } else {
                burstRequested = true;
            }
            overloadTicks = 0;
        }

        // 6: конденсат по сравнению со значением 2 секунды назад
        if (condensateCooldown > 0) {
            condensateCooldown -= dtTicks;
        } else {
            float amount = CondensateModel.dropAmount(getPressureAgo(8), cachedPressure);
            if (amount > 0.0f) {
                condensateAmount = amount;
                condensateCooldown = CondensateModel.COOLDOWN_TICKS;
            }
        }

        // 7: шум — Milestone 4
        if (equalizeTicks > 0) {
            equalizeTicks = Math.max(0, equalizeTicks - dtTicks);
        }
        forceStep = false;
    }

    // ------------------------------------------------------------------ кэши и запросы к миру

    public boolean isCachesDirty() { return cachesDirty; }
    public void markCachesDirty() { cachesDirty = true; forceStep = true; }

    /** Менеджер пересчитывает кэши (сумма утечек, слабейший узел) после изменений и записывает их сюда. */
    public void setCaches(double leakSum, float minBurstLimit, float minVacuumLimit, @Nullable BlockPos weakest) {
        this.leakSum = leakSum;
        this.minBurstLimit = minBurstLimit;
        this.minVacuumLimit = minVacuumLimit;
        this.weakest = weakest;
        this.cachesDirty = false;
    }

    public double getLeakSum() { return leakSum; }
    public float getMinBurstLimit() { return minBurstLimit; }
    public float getMinVacuumLimit() { return minVacuumLimit; }
    public @Nullable BlockPos getWeakest() { return weakest; }
    public int getOverloadTicks() { return overloadTicks; }

    public boolean consumeBurstRequest() { boolean r = burstRequested; burstRequested = false; return r; }
    public boolean consumeImplodeRequest() { boolean r = implodeRequested; implodeRequested = false; return r; }
    public float consumeCondensate() { float c = condensateAmount; condensateAmount = 0.0f; return c; }

    public boolean isPressurizedFlag() { return pressurizedFlag; }
    public void setPressurizedFlag(boolean flag) { this.pressurizedFlag = flag; }

    private void refreshPressure() {
        cachedPressure = (float) computePressure();
    }

    private void pushHistory(float p) {
        if (!histValid) {
            java.util.Arrays.fill(pHist, p);
            histHead = 0;
            histValid = true;
            return;
        }
        histHead = (histHead + 1) % pHist.length;
        pHist[histHead] = p;
    }

    /** Давление {@code stepsAgo} шагов назад (0 — последний). 8 шагов = 2 секунды (правило конденсата, 2.6). */
    public float getPressureAgo(int stepsAgo) {
        if (!histValid) {
            return cachedPressure;
        }
        int steps = Math.max(0, Math.min(pHist.length - 1, stepsAgo));
        return pHist[Math.floorMod(histHead - steps, pHist.length)];
    }

    public void requestStep() {
        forceStep = true;
    }

    /** Возвращает и сбрасывает флаг forceStep. */
    public boolean consumeForceStep() {
        boolean was = forceStep;
        forceStep = false;
        return was;
    }

    // ------------------------------------------------------------------ слияние и разделение

    /**
     * Слияние (A.3.2): масса и объём складываются, давление сразу становится {@code 100 × (M1 + M2) / (V1 + V2)}.
     * Температура сети — взвешенная по |M|. Узлы и индексы других сетей менеджер переносит сам.
     */
    public PressureNetwork merge(PressureNetwork other) {
        double wa = Math.abs(mass);
        double wb = Math.abs(other.mass);
        if (wa + wb > 1.0e-9) {
            temperature = (float) ((wa * temperature + wb * other.temperature) / (wa + wb));
        }
        mass += other.mass;
        volume += other.volume;
        pendingDelta += other.pendingDelta;
        blocks.addAll(other.blocks);
        nodeVolumes.putAll(other.nodeVolumes);
        machines.addAll(other.machines);
        unloadedChunks.addAll(other.unloadedChunks);
        if (owner == null) {
            owner = other.owner;
        }
        if (other.state == State.SLEEPING && state == State.ACTIVE) {
            state = State.SLEEPING;
        }
        equalizeTicks = PressureConstants.EQUALIZE_TICKS;
        forceStep = true;
        cachesDirty = true;
        refreshPressure();
        return this;
    }

    /**
     * Разделение по найденным компонентам связности (A.3.3). Масса делится по объёму:
     * {@code M_i = M × V_i / ΣV}, поэтому давление в каждой части прежнее.
     * Самая большая по объёму компонента остаётся в этом объекте (сохраняет id), остальные
     * становятся новыми сетями. Возвращает список, где первый элемент — this.
     * Узел, чей слом вызвал разделение, должен быть уже убран через {@link #removeNode(BlockPos)}.
     */
    public List<PressureNetwork> split(List<? extends Collection<BlockPos>> components) {
        List<PressureNetwork> result = new ArrayList<>();
        result.add(this);
        if (components.size() <= 1) {
            return result;
        }

        double totalMass = mass;
        int totalVolume = volume;
        LongSet unloadedBefore = new LongOpenHashSet(unloadedChunks);

        int[] volumes = new int[components.size()];
        int mainIndex = 0;
        int mainVolume = -1;
        for (int i = 0; i < components.size(); i++) {
            int v = 0;
            for (BlockPos p : components.get(i)) {
                v += nodeVolumes.getOrDefault(p, 0);
            }
            volumes[i] = v;
            if (v > mainVolume) {
                mainVolume = v;
                mainIndex = i;
            }
        }

        for (int i = 0; i < components.size(); i++) {
            if (i == mainIndex) {
                continue;
            }
            PressureNetwork fresh = new PressureNetwork(UUID.randomUUID());
            for (BlockPos p : components.get(i)) {
                Integer v = nodeVolumes.remove(p);
                blocks.remove(p);
                if (machines.remove(p)) {
                    fresh.machines.add(p);
                }
                fresh.blocks.add(p);
                fresh.nodeVolumes.put(p, v == null ? 0 : v);
                long chunk = ChunkPos.asLong(p);
                if (unloadedBefore.contains(chunk)) {
                    fresh.unloadedChunks.add(chunk);
                }
            }
            fresh.volume = volumes[i];
            fresh.mass = totalVolume > 0 ? totalMass * volumes[i] / totalVolume : 0.0;
            fresh.temperature = temperature;
            fresh.owner = owner;
            fresh.copyHistoryFrom(this);
            fresh.refreshPressure();
            fresh.forceStep = true;
            fresh.cachesDirty = true;
            fresh.overloadTicks = overloadTicks;
            result.add(fresh);
        }

        volume = volumes[mainIndex];
        mass = totalVolume > 0 ? totalMass * volumes[mainIndex] / totalVolume : 0.0;
        pruneUnloadedChunks();
        forceStep = true;
        cachesDirty = true;
        refreshPressure();
        return result;
    }

    private void copyHistoryFrom(PressureNetwork src) {
        System.arraycopy(src.pHist, 0, pHist, 0, pHist.length);
        histHead = src.histHead;
        histValid = src.histValid;
    }

    // ------------------------------------------------------------------ чанки

    public boolean hasNodeInChunk(long chunkKey) {
        for (BlockPos p : blocks) {
            if (ChunkPos.asLong(p) == chunkKey) {
                return true;
            }
        }
        return false;
    }

    /** Убирает из списка выгруженных чанки, где у сети больше нет узлов. */
    private void pruneUnloadedChunks() {
        if (unloadedChunks.isEmpty()) {
            return;
        }
        LongIterator it = unloadedChunks.iterator();
        while (it.hasNext()) {
            if (!hasNodeInChunk(it.nextLong())) {
                it.remove();
            }
        }
    }

    /** Все чанки, где у сети есть узлы. */
    public LongSet getNodeChunks() {
        LongSet set = new LongOpenHashSet();
        for (BlockPos p : blocks) {
            set.add(ChunkPos.asLong(p));
        }
        return set;
    }

    public void markChunkUnloaded(long chunkKey) {
        unloadedChunks.add(chunkKey);
        if (state == State.ACTIVE) {
            state = State.SLEEPING;
        }
    }

    public void markChunkLoaded(long chunkKey) {
        unloadedChunks.remove(chunkKey);
        if (state == State.SLEEPING && unloadedChunks.isEmpty()) {
            state = State.ACTIVE;
        }
    }

    /** После чтения с диска все чанки считаются выгруженными, пока не придёт событие загрузки. */
    public void markAllUnloaded() {
        unloadedChunks.clear();
        unloadedChunks.addAll(getNodeChunks());
        if (!blocks.isEmpty() && state != State.REBUILDING) {
            state = State.SLEEPING;
        }
    }

    public LongSet getUnloadedChunks() {
        return unloadedChunks;
    }

    // ------------------------------------------------------------------ NBT

    public CompoundTag save() {
        CompoundTag tag = new CompoundTag();
        tag.putUUID("id", id);
        tag.putDouble("mass", mass);
        tag.putFloat("temp", temperature);
        if (owner != null) {
            tag.putUUID("owner", owner);
        }
        long[] positions = new long[blocks.size()];
        int[] vols = new int[blocks.size()];
        int i = 0;
        for (Map.Entry<BlockPos, Integer> e : nodeVolumes.entrySet()) {
            positions[i] = e.getKey().asLong();
            vols[i] = e.getValue();
            i++;
        }
        tag.putLongArray("pos", positions);
        tag.putIntArray("vol", vols);
        long[] machinePositions = new long[machines.size()];
        int mi = 0;
        for (BlockPos m : machines) {
            machinePositions[mi++] = m.asLong();
        }
        tag.putLongArray("mach", machinePositions);
        if (histValid) {
            ListTag hist = new ListTag();
            for (float f : pHist) {
                hist.add(FloatTag.valueOf(f));
            }
            tag.put("hist", hist);
            tag.putInt("head", histHead);
        }
        return tag;
    }

    public static PressureNetwork load(CompoundTag tag) {
        PressureNetwork net = new PressureNetwork(tag.getUUID("id"));
        net.mass = tag.getDouble("mass");
        net.temperature = tag.getFloat("temp");
        if (tag.hasUUID("owner")) {
            net.owner = tag.getUUID("owner");
        }
        long[] positions = tag.getLongArray("pos");
        int[] vols = tag.getIntArray("vol");
        int n = Math.min(positions.length, vols.length);
        for (int i = 0; i < n; i++) {
            BlockPos p = BlockPos.of(positions[i]);
            net.blocks.add(p);
            net.nodeVolumes.put(p, vols[i]);
            net.volume += vols[i];
        }
        for (long m : tag.getLongArray("mach")) {
            BlockPos mp = BlockPos.of(m);
            if (net.blocks.contains(mp)) {
                net.machines.add(mp);
            }
        }
        ListTag hist = tag.getList("hist", Tag.TAG_FLOAT);
        if (hist.size() == net.pHist.length) {
            for (int i = 0; i < net.pHist.length; i++) {
                net.pHist[i] = hist.getFloat(i);
            }
            net.histHead = Math.floorMod(tag.getInt("head"), net.pHist.length);
            net.histValid = true;
        }
        net.refreshPressure();
        return net;
    }

    // ------------------------------------------------------------------ аксессоры

    public UUID getId() { return id; }
    public double getMass() { return mass; }
    public int getVolume() { return volume; }
    public State getState() { return state; }
    public void setState(State state) { this.state = state; }
    public float getTemperature() { return temperature; }
    public void setTemperature(float temperature) { this.temperature = temperature; }
    public @Nullable UUID getOwner() { return owner; }
    public void setOwner(@Nullable UUID owner) { this.owner = owner; }
    public int getEqualizeTicks() { return equalizeTicks; }
    public long getLastStepTick() { return lastStepTick; }
    public void setLastStepTick(long tick) { this.lastStepTick = tick; }
    public double getPendingDelta() { return pendingDelta; }

    @Override
    public String toString() {
        return "PressureNetwork[" + id + ", nodes=" + blocks.size() + ", V=" + volume
                + ", M=" + String.format("%.3f", mass) + ", P=" + String.format("%.1f", cachedPressure)
                + ", " + state + "]";
    }
}
