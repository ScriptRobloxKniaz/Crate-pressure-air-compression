package dev.cpp.block;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.cpp.pressure.core.PipeTier;
import net.minecraft.world.level.block.BaseEntityBlock;

/** Конкретная труба одного материала. Codec нужен BaseEntityBlock; материал сериализуется в нём. */
public final class PressurePipeBlock extends AbstractPressurePipeBlock {

    public static final MapCodec<PressurePipeBlock> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            propertiesCodec(),
            PipeTier.CODEC.fieldOf("tier").forGetter(PressurePipeBlock::tier)
    ).apply(instance, PressurePipeBlock::new));

    private final PipeTier tier;

    public PressurePipeBlock(Properties properties, PipeTier tier) {
        super(properties);
        this.tier = tier;
    }

    @Override
    public PipeTier tier() {
        return tier;
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return CODEC;
    }
}
