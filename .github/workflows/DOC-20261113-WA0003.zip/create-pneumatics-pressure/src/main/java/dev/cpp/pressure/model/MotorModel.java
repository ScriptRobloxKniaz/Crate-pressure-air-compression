package dev.cpp.pressure.model;

/**
 * Пневматический двигатель (раздел 3.2, константы пересчитаны в 3.4):
 * RPM = min(256, 4.5 × √P), расход 0.075 ед./RPM, выход 2.0 су/RPM, запуск от 50 PSI.
 */
public final class MotorModel {
    private MotorModel() {}

    public static final float START_PSI = 50.0f;
    public static final float RPM_COEF = 4.5f;
    public static final float MAX_RPM = 256.0f;
    public static final float MASS_PER_RPM = 0.075f;
    public static final float SU_PER_RPM = 2.0f;

    /** Целевые обороты при давлении p0 (0 ниже порога запуска). */
    public static double targetRpm(float p0) {
        if (p0 < START_PSI) {
            return 0.0;
        }
        return Math.min(MAX_RPM, RPM_COEF * Math.sqrt(p0));
    }

    /** Шаг 2 из A.2: сколько массы двигатель хочет забрать за шаг при целевых оборотах. */
    public static double demand(float p0, int dtTicks) {
        return MASS_PER_RPM * targetRpm(p0) * (dtTicks / 20.0);
    }

    /** Ёмкость стресса, су на 1 RPM. */
    public static float capacityPerRpm() {
        return SU_PER_RPM;
    }
}
