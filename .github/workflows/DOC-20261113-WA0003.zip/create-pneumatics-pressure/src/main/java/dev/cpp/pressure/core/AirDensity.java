package dev.cpp.pressure.core;

import dev.cpp.pressure.model.AirDensityModel;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;

/** Плотность воздуха в точке (раздел 2.8): по высоте в Верхнем мире, константа в Незере и Крае. */
public final class AirDensity {
    private AirDensity() {}

    public static float at(Level level, BlockPos pos) {
        if (level.dimension() == Level.NETHER) {
            return AirDensityModel.NETHER;
        }
        if (level.dimension() == Level.END) {
            return AirDensityModel.END;
        }
        return AirDensityModel.overworld(pos.getY());
    }
}
