package dev.cpp.block;

import com.mojang.serialization.MapCodec;
import com.simibubi.create.content.kinetics.base.RotatedPillarKineticBlock;
import com.simibubi.create.foundation.block.IBE;
import dev.cpp.blockentity.PneumaticMotorBlockEntity;
import dev.cpp.pressure.api.IPressurePort;
import dev.cpp.pressure.core.PressureManager;
import dev.cpp.registry.ModRegistries;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;

/** Пневматический двигатель: порты воздуха на боковых гранях, вал по оси AXIS отдаёт вращение в сеть Create. */
public class PneumaticMotorBlock extends RotatedPillarKineticBlock
        implements IBE<PneumaticMotorBlockEntity>, IPressurePort {

    public static final MapCodec<PneumaticMotorBlock> CODEC = simpleCodec(PneumaticMotorBlock::new);

    public PneumaticMotorBlock(Properties properties) {
        super(properties);
    }

    @Override
    protected MapCodec<PneumaticMotorBlock> codec() {
        return CODEC;
    }

    @Override
    public boolean hasPressurePort(BlockState state, Direction face) {
        return face.getAxis() != state.getValue(AXIS);
    }

    @Override
    public Class<PneumaticMotorBlockEntity> getBlockEntityClass() {
        return PneumaticMotorBlockEntity.class;
    }

    @Override
    public BlockEntityType<? extends PneumaticMotorBlockEntity> getBlockEntityType() {
        return ModRegistries.MOTOR.get();
    }

    @Override
    protected void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
        if (!state.is(newState.getBlock()) && level instanceof ServerLevel serverLevel) {
            PressureManager.get(serverLevel).onRemoved(pos);
        }
        super.onRemove(state, level, pos, newState, movedByPiston);
    }
}
