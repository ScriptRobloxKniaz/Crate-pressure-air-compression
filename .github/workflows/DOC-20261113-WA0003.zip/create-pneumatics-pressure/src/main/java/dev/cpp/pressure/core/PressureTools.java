package dev.cpp.pressure.core;

import dev.cpp.pressure.api.IPressureHandler;
import dev.cpp.pressure.api.PressureCapabilities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

/** Операции игрока над соединениями: затяжка стыка и прямой секции. Вызываются только на сервере. */
public final class PressureTools {
    private PressureTools() {}

    private static final int MAX_RUN = 64;

    public static @Nullable IPressureHandler handler(Level level, BlockPos pos) {
        return level.isLoaded(pos) ? level.getCapability(PressureCapabilities.PRESSURE, pos, null) : null;
    }

    /**
     * Затягивает стык {@code pos} — {@code pos.relative(face)} до 100 % с обеих сторон.
     *
     * @return true, если стык существует и хотя бы одна сторона изменилась
     */
    public static boolean tightenJoint(Level level, BlockPos pos, Direction face) {
        IPressureHandler a = handler(level, pos);
        IPressureHandler b = handler(level, pos.relative(face));
        if (a == null || b == null || !a.canConnect(face) || !b.canConnect(face.getOpposite())) {
            return false;
        }
        boolean changed = a.getSealLevel(face) < IPressureHandler.MAX_SEAL
                || b.getSealLevel(face.getOpposite()) < IPressureHandler.MAX_SEAL;
        a.setSealLevel(face, IPressureHandler.MAX_SEAL);
        b.setSealLevel(face.getOpposite(), IPressureHandler.MAX_SEAL);
        return changed;
    }

    /** Затягивает все стыки блока. @return число стыков, которые были ослаблены. */
    public static int tightenBlock(Level level, BlockPos pos) {
        int count = 0;
        for (Direction face : Direction.values()) {
            if (tightenJoint(level, pos, face)) {
                count++;
            }
        }
        return count;
    }

    private static int connectedFaces(Level level, BlockPos pos) {
        IPressureHandler h = handler(level, pos);
        if (h == null) {
            return 0;
        }
        int n = 0;
        for (Direction face : Direction.values()) {
            if (h.canConnect(face)) {
                n++;
            }
        }
        return n;
    }

    /**
     * Затягивает прямую секцию вдоль оси {@code axisFace} в обе стороны от {@code start} до разветвления
     * (узел, у которого не ровно два соединения) или до 64 блоков.
     */
    public static int tightenRun(Level level, BlockPos start, Direction axisFace) {
        int count = 0;
        for (Direction dir : new Direction[] {axisFace, axisFace.getOpposite()}) {
            BlockPos current = start;
            for (int i = 0; i < MAX_RUN; i++) {
                if (tightenJoint(level, current, dir)) {
                    count++;
                }
                BlockPos next = current.relative(dir);
                IPressureHandler h = handler(level, next);
                IPressureHandler cur = handler(level, current);
                if (h == null || cur == null || !cur.canConnect(dir) || !h.canConnect(dir.getOpposite())
                        || connectedFaces(level, next) != 2) {
                    break;
                }
                current = next;
            }
        }
        return count;
    }
}
