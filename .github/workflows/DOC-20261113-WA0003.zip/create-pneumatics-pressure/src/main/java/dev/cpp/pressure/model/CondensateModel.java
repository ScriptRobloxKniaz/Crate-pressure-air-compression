package dev.cpp.pressure.model;

/** Конденсат (раздел 2.6): образуется при резком сбросе давления. */
public final class CondensateModel {
    private CondensateModel() {}

    /** Падение давления за окно, с которого образуется конденсат (доля от значения 2 секунды назад). */
    public static final float DROP_FRACTION = 0.30f;
    /** Ниже этого давления резкие падения игнорируются (иначе шум у нуля даёт ложные срабатывания). */
    public static final float MIN_PRESSURE = 20.0f;
    public static final float PER_PSI = 0.02f;
    public static final float MAX_PER_SEGMENT = 4.0f;
    /** Пауза между событиями, тики (иначе затяжное падение давало бы событие на каждом шаге). */
    public static final int COOLDOWN_TICKS = 40;

    /** Сколько конденсата получает каждый сегмент: ΔP / 50, если P упало более чем на 30 % относительно значения 2 сек назад. */
    public static float dropAmount(float pressureTwoSecondsAgo, float pressureNow) {
        if (pressureTwoSecondsAgo < MIN_PRESSURE) {
            return 0.0f;
        }
        float drop = pressureTwoSecondsAgo - pressureNow;
        if (drop <= DROP_FRACTION * pressureTwoSecondsAgo) {
            return 0.0f;
        }
        return drop * PER_PSI;
    }
}
