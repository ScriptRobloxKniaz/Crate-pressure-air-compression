package dev.cpp.client;

import com.simibubi.create.content.equipment.goggles.GogglesItem;
import dev.cpp.CppMod;
import dev.cpp.pressure.api.IPressureHandler;
import dev.cpp.network.ProbeRequest;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * Пока игрок в очках Create смотрит на узел сети, раз в 10 тиков отправляется тихий ProbeRequest (A.4).
 * Ответ попадает в {@link ClientPressureCache}, откуда его берёт подсказка очков.
 */
@EventBusSubscriber(modid = CppMod.MODID, value = Dist.CLIENT)
public final class ClientGoggleProbe {
    private ClientGoggleProbe() {}

    private static final int INTERVAL_TICKS = 10;
    private static int counter;

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.level == null) {
            return;
        }
        if (++counter % INTERVAL_TICKS != 0) {
            return;
        }
        if (!GogglesItem.isWearingGoggles(player)) {
            return;
        }
        if (!(mc.hitResult instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) {
            return;
        }
        BlockPos pos = hit.getBlockPos();
        if (mc.level.getBlockEntity(pos) instanceof IPressureHandler) {
            PacketDistributor.sendToServer(new ProbeRequest(pos, false, false));
        }
    }
}
