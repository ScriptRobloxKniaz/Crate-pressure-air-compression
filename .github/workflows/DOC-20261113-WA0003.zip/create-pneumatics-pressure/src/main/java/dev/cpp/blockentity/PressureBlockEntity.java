package dev.cpp.blockentity;

import com.simibubi.create.content.equipment.goggles.IHaveGoggleInformation;
import dev.cpp.CppMod;
import dev.cpp.goggles.PressureGoggleLines;
import dev.cpp.block.AbstractPressurePipeBlock;
import dev.cpp.block.PipeConnection;
import dev.cpp.pressure.api.IPressureHandler;
import dev.cpp.pressure.core.PipeTier;
import dev.cpp.pressure.model.CondensateModel;
import dev.cpp.pressure.core.PressureManager;
import dev.cpp.pressure.core.PressureNetwork;
import dev.cpp.registry.ModRegistries;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.entity.BlockEntity;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * Узел сети давления. Хранит поля из A.1: tier, mass (снимок доли узла), sealLevel[6], wear, condensate,
 * temperature, leakType, leakFace, overpressureTicks. Логика утечек, нагрева и перегрузки появится позже,
 * в Milestone 1 поля только читаются и пишутся.
 */
public class PressureBlockEntity extends BlockEntity implements IPressureHandler, IHaveGoggleInformation {

    private PipeTier tier;
    private double mass;
    private final int[] sealLevel = new int[6];
    private float wear;
    private float condensate;
    private float temperature = 20.0f;
    private byte leakType;
    private byte leakFace = -1;
    private short overpressureTicks;

    public PressureBlockEntity(BlockPos pos, BlockState state) {
        super(ModRegistries.PRESSURE_NODE.get(), pos, state);
        this.tier = state.getBlock() instanceof AbstractPressurePipeBlock pipe ? pipe.tier() : PipeTier.COPPER;
    }

    // ------------------------------------------------------------------ жизненный цикл

    /** Вызывается и при установке, и при загрузке чанка: менеджер игнорирует уже известные узлы. */
    @Override
    public void onLoad() {
        super.onLoad();
        if (level instanceof ServerLevel serverLevel) {
            PressureManager.get(serverLevel).onPlaced(worldPosition);
        }
    }

    // ------------------------------------------------------------------ NBT

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putByte("tier", (byte) tier.ordinal());
        tag.putDouble("mass", snapshotMass());
        tag.putIntArray("seal", sealLevel);
        tag.putFloat("wear", wear);
        tag.putFloat("condensate", condensate);
        tag.putFloat("temperature", temperature);
        tag.putByte("leakType", leakType);
        tag.putByte("leakFace", leakFace);
        tag.putShort("overpressureTicks", overpressureTicks);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        if (tag.contains("tier")) {
            tier = PipeTier.byOrdinal(tag.getByte("tier"));
        }
        mass = tag.getDouble("mass");
        int[] seal = tag.getIntArray("seal");
        for (int i = 0; i < sealLevel.length; i++) {
            sealLevel[i] = i < seal.length ? Math.max(0, Math.min(MAX_SEAL, seal[i])) : 0;
        }
        wear = tag.getFloat("wear");
        condensate = tag.getFloat("condensate");
        temperature = tag.contains("temperature") ? tag.getFloat("temperature") : 20.0f;
        leakType = tag.getByte("leakType");
        leakFace = tag.contains("leakFace") ? tag.getByte("leakFace") : -1;
        overpressureTicks = tag.getShort("overpressureTicks");
    }

    /** Доля массы сети, приходящаяся на этот узел. Если сети нет, остаётся прежний снимок. */
    private double snapshotMass() {
        if (level instanceof ServerLevel serverLevel) {
            PressureNetwork net = PressureManager.get(serverLevel).getNetworkAt(worldPosition);
            if (net != null) {
                mass = net.getNodeMassShare(worldPosition);
            }
        }
        return mass;
    }

    // ------------------------------------------------------------------ IPressureHandler

    @Override
    public int getVolume() {
        return tier.getVolume();
    }

    @Override
    public float getLimit() {
        return tier.getBurstLimit();
    }

    @Override
    public float getVacuumLimit() {
        return tier.getVacuumLimit();
    }

    @Override
    public boolean canConnect(Direction face) {
        BlockState state = getBlockState();
        if (!(state.getBlock() instanceof AbstractPressurePipeBlock)) {
            return false;
        }
        return AbstractPressurePipeBlock.connectionOf(state, face).isConnected();
    }

    @Override
    public int getSealLevel(Direction face) {
        return sealLevel[face.get3DDataValue()];
    }

    @Override
    public void setSealLevel(Direction face, int level) {
        sealLevel[face.get3DDataValue()] = Math.max(0, Math.min(MAX_SEAL, level));
        setChanged();
        notifyLeakChange();
    }

    @Override
    public boolean isOpenPort(Direction face) {
        BlockState state = getBlockState();
        return state.getBlock() instanceof AbstractPressurePipeBlock
                && AbstractPressurePipeBlock.connectionOf(state, face) == PipeConnection.PORT;
    }

    @Override
    public void applyWear(float amount) {
        wear = Math.max(0.0f, Math.min(100.0f, wear + amount));
        setChanged();
        notifyLeakChange();
    }

    /** Утечка узла могла измениться: сеть пересчитает кэши на ближайшем шаге. */
    private void notifyLeakChange() {
        if (level instanceof ServerLevel serverLevel) {
            PressureManager.get(serverLevel).markNodeDirty(worldPosition);
        }
    }

    @Override
    public void setLeaking(boolean leaking) {
        updateState(AbstractPressurePipeBlock.SEALED, !leaking);
    }

    @Override
    public void setPressurized(boolean pressurized) {
        updateState(AbstractPressurePipeBlock.PRESSURIZED, pressurized);
    }

    private void updateState(BooleanProperty property, boolean value) {
        BlockState state = getBlockState();
        if (level != null && state.hasProperty(property) && state.getValue(property) != value) {
            level.setBlock(worldPosition, state.setValue(property, value), Block.UPDATE_CLIENTS);
        }
    }

    @Override
    public void addCondensate(float amount) {
        condensate = Math.min(CondensateModel.MAX_PER_SEGMENT, condensate + amount);
        setChanged();
    }

    @Override
    public float getWorkingMax() {
        return tier.getWorkingMax();
    }

    @Override
    public double getSavedMass() {
        return mass;
    }

    @Override
    public void onNetworkChanged(@Nullable PressureNetwork network) {
        // Milestone 1: ничего не кэшируем; сеть всегда запрашивается у менеджера по позиции.
    }

    @Override
    public void onConnectionRefused() {
        CppMod.LOGGER.warn("Pressure node at {} refused: network size limit reached", worldPosition);
    }

    // ------------------------------------------------------------------ очки Create

    /** Подсказка очков Create; данные берутся из клиентского кэша, который наполняет ClientGoggleProbe. */
    @Override
    public boolean addToGoggleTooltip(List<Component> tooltip, boolean isPlayerSneaking) {
        PressureGoggleLines.add(tooltip, worldPosition, this, isPlayerSneaking, tier.getWorkingMax());
        return true;
    }

    // ------------------------------------------------------------------ аксессоры (поля A.1)

    public PipeTier getTier() { return tier; }
    public float getWear() { return wear; }
    public float getCondensate() { return condensate; }
    public float getTemperature() { return temperature; }
    public byte getLeakType() { return leakType; }
    public byte getLeakFace() { return leakFace; }
    public short getOverpressureTicks() { return overpressureTicks; }
}
