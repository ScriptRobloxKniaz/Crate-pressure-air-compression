package dev.cpp.item;

import dev.cpp.block.AbstractPressurePipeBlock;
import dev.cpp.block.PipeConnection;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

/** Заглушка порта: закрывает открытый конец трубы (PORT → PLUG), и утечка через него прекращается. */
public class PortPlugItem extends Item {

    public PortPlugItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        BlockPos pos = context.getClickedPos();
        BlockState state = level.getBlockState(pos);
        if (!(state.getBlock() instanceof AbstractPressurePipeBlock)) {
            return InteractionResult.PASS;
        }
        if (level.isClientSide) {
            return InteractionResult.sidedSuccess(true);
        }

        Direction target = null;
        Direction clicked = context.getClickedFace();
        if (AbstractPressurePipeBlock.connectionOf(state, clicked) == PipeConnection.PORT) {
            target = clicked;
        } else {
            for (Direction dir : Direction.values()) {
                if (AbstractPressurePipeBlock.connectionOf(state, dir) == PipeConnection.PORT) {
                    target = dir;
                    break;
                }
            }
        }
        Player player = context.getPlayer();
        if (target == null) {
            if (player != null) {
                player.displayClientMessage(Component.translatable("cpp.plug.no_port"), true);
            }
            return InteractionResult.CONSUME;
        }
        level.setBlock(pos, state.setValue(AbstractPressurePipeBlock.property(target), PipeConnection.PLUG), 3);
        level.playSound(null, pos, SoundEvents.COPPER_PLACE, SoundSource.BLOCKS, 1.0f, 1.2f);
        if (player == null || !player.getAbilities().instabuild) {
            context.getItemInHand().shrink(1);
        }
        return InteractionResult.CONSUME;
    }
}
