package dev.cpp.client;

import dev.cpp.network.ProbeResult;
import net.minecraft.core.BlockPos;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Клиентский кэш последних ответов сервера по позициям узлов. Читается оверлеем очков Create.
 * Запись считается устаревшей через 2 секунды: если игрок отвернулся, данные исчезают.
 */
public final class ClientPressureCache {
    private ClientPressureCache() {}

    private static final long TTL_MILLIS = 2000L;
    private static final int MAX_ENTRIES = 64;

    private record Entry(ProbeResult result, long timeMillis) {}

    private static final Map<BlockPos, Entry> ENTRIES = new HashMap<>();

    public static void put(ProbeResult result) {
        long now = System.currentTimeMillis();
        if (ENTRIES.size() >= MAX_ENTRIES) {
            Iterator<Entry> it = ENTRIES.values().iterator();
            while (it.hasNext()) {
                if (now - it.next().timeMillis() > TTL_MILLIS) {
                    it.remove();
                }
            }
            if (ENTRIES.size() >= MAX_ENTRIES) {
                ENTRIES.clear();
            }
        }
        ENTRIES.put(result.pos().immutable(), new Entry(result, now));
    }

    public static @Nullable ProbeResult get(BlockPos pos) {
        Entry entry = ENTRIES.get(pos);
        if (entry == null) {
            return null;
        }
        if (System.currentTimeMillis() - entry.timeMillis() > TTL_MILLIS) {
            ENTRIES.remove(pos);
            return null;
        }
        return entry.result();
    }
}
