package dev.cpp.blockentity;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import dev.cpp.pressure.api.IPressureHandler;
import dev.cpp.pressure.core.PressureManager;
import dev.cpp.pressure.core.PressureNetwork;

/**
 * Общие поля узла сети из A.1 (затяжка, износ, конденсат, снимок массы) для BlockEntity машин.
 * Машины наследуют Create-классы и не могут наследовать PressureBlockEntity, поэтому используют композицию.
 */
public final class PressureNodeState {
    private final int[] seal = new int[6];
    private float wear;
    private float condensate;
    private double mass;

    public int getSeal(Direction face) {
        return seal[face.get3DDataValue()];
    }

    public void setSeal(Direction face, int level) {
        seal[face.get3DDataValue()] = Math.max(0, Math.min(IPressureHandler.MAX_SEAL, level));
    }

    public float getWear() { return wear; }
    public float getCondensate() { return condensate; }
    public double getMass() { return mass; }

    public void applyWear(float amount) {
        wear = Math.max(0.0f, Math.min(100.0f, wear + amount));
    }

    /** Записывает поля; на сервере массу берёт как долю узла из сети. */
    public void write(CompoundTag tag, Level level, BlockPos pos) {
        if (level instanceof ServerLevel serverLevel) {
            PressureNetwork net = PressureManager.get(serverLevel).getNetworkAt(pos);
            if (net != null) {
                mass = net.getNodeMassShare(pos);
            }
        }
        tag.putDouble("mass", mass);
        tag.putIntArray("seal", seal);
        tag.putFloat("wear", wear);
        tag.putFloat("condensate", condensate);
    }

    public void read(CompoundTag tag) {
        mass = tag.getDouble("mass");
        int[] stored = tag.getIntArray("seal");
        for (int i = 0; i < seal.length; i++) {
            seal[i] = i < stored.length ? Math.max(0, Math.min(IPressureHandler.MAX_SEAL, stored[i])) : 0;
        }
        wear = tag.getFloat("wear");
        condensate = tag.getFloat("condensate");
    }
}
