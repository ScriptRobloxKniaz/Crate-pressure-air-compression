package dev.cpp.pressure.api;

/**
 * Машина, которая добавляет или забирает воздух (компрессор, двигатель, позже толкатель и т. д.).
 * Сеть вызывает методы в порядке A.2: produce → demand → onSupplied → (утечка) → postStep.
 * P₀ — давление на начало шага, P₁ — после обновления массы. Вызывается только с серверного потока.
 */
public interface IPressureMachine {

    /** Шаг 1: масса, добавленная в сеть за шаг (для вакуумного насоса — отрицательная). */
    default double produce(float p0, int dtTicks) {
        return 0.0;
    }

    /** Шаг 2: сколько массы машина хочет забрать за шаг (≥ 0). */
    default double demand(float p0, int dtTicks) {
        return 0.0;
    }

    /** Шаг 2, результат: доля запрошенного, которую сеть смогла отдать (0..1). */
    default void onSupplied(double fraction) {}

    /** Шаг 4: итоговое давление P₁ (после утечки) для нагрева и обновления стресса. */
    default void postStep(float p1, int dtTicks) {}
}
