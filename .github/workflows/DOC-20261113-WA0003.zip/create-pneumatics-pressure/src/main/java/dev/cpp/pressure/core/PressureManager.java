package dev.cpp.pressure.core;

import dev.cpp.CppMod;
import dev.cpp.pressure.api.IPressureHandler;
import dev.cpp.pressure.api.IPressureMachine;
import dev.cpp.pressure.api.PressureCapabilities;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.longs.LongArrayList;
import it.unimi.dsi.fastutil.longs.LongIterator;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import it.unimi.dsi.fastutil.longs.LongSet;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.saveddata.SavedData;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Менеджер сетей давления одного уровня (A.2, A.3). Хранит сети, индекс узлов, очередь топологических
 * событий и инкрементальные задачи разделения. Все методы вызываются с главного серверного потока.
 *
 * <p>Порядок тика: проверка чанков после загрузки → продолжение обходов графа → разбор очереди →
 * шаг активных сетей (раз в 5 тиков, фазы разнесены по id).
 */
public final class PressureManager extends SavedData {

    public static final String DATA_NAME = CppMod.MODID + "_pressure";

    private static final SavedData.Factory<PressureManager> FACTORY =
            new SavedData.Factory<>(PressureManager::new, PressureManager::load, null);

    // ------------------------------------------------------------------ состояние

    private final Map<UUID, PressureNetwork> networks = new HashMap<>();
    private final Map<BlockPos, UUID> nodeIndex = new HashMap<>();
    /** chunk -> id сетей, у которых там есть (или были) узлы. Устаревшие записи чистятся лениво. */
    private final Long2ObjectOpenHashMap<Set<UUID>> chunkIndex = new Long2ObjectOpenHashMap<>();
    private final Deque<TopologyEvent> queue = new ArrayDeque<>();
    private final Map<UUID, SplitJob> jobs = new HashMap<>();
    private final LongSet pendingVerify = new LongOpenHashSet();
    private final List<IPressureMachine> machineScratch = new ArrayList<>();

    private @Nullable ServerLevel level;
    private long tickCounter;
    private int bfsBudget;
    private boolean changed;

    public PressureManager() {}

    // ------------------------------------------------------------------ доступ

    public static PressureManager get(ServerLevel level) {
        PressureManager manager = level.getDataStorage().computeIfAbsent(FACTORY, DATA_NAME);
        manager.attach(level);
        return manager;
    }

    private void attach(ServerLevel serverLevel) {
        if (this.level == serverLevel) {
            return;
        }
        this.level = serverLevel;
        refreshLoadedChunks();
    }

    public @Nullable PressureNetwork getNetworkAt(BlockPos pos) {
        UUID id = nodeIndex.get(pos);
        return id == null ? null : networks.get(id);
    }

    public @Nullable PressureNetwork getNetwork(UUID id) {
        return networks.get(id);
    }

    public Map<UUID, PressureNetwork> getNetworks() {
        return Collections.unmodifiableMap(networks);
    }

    /** Доля массы узла для записи в NBT его BlockEntity (A.1: mass хранится снимком). */
    public double getNodeMassShare(BlockPos pos) {
        PressureNetwork net = getNetworkAt(pos);
        return net == null ? 0.0 : net.getNodeMassShare(pos);
    }

    // ------------------------------------------------------------------ события

    /** Узел установлен или загружен. Безопасно вызывать повторно: уже известный узел игнорируется. */
    public void onPlaced(BlockPos pos) {
        queue.addLast(new TopologyEvent(TopologyEvent.Type.PLACED, pos.immutable()));
    }

    /** Узел удалён. Вызывать из BlockEntity.setRemoved() / Block.onRemove(). */
    public void onRemoved(BlockPos pos) {
        queue.addLast(new TopologyEvent(TopologyEvent.Type.REMOVED, pos.immutable()));
    }

    public void onChunkUnload(ChunkPos chunkPos) {
        long key = chunkPos.toLong();
        Set<UUID> ids = chunkIndex.get(key);
        if (ids == null) {
            return;
        }
        Iterator<UUID> it = ids.iterator();
        while (it.hasNext()) {
            PressureNetwork net = networks.get(it.next());
            if (net == null || !net.hasNodeInChunk(key)) {
                it.remove();
                continue;
            }
            net.markChunkUnloaded(key);
        }
        if (ids.isEmpty()) {
            chunkIndex.remove(key);
        }
    }

    public void onChunkLoad(ChunkPos chunkPos) {
        markChunkLoaded(chunkPos.toLong());
    }

    private void markChunkLoaded(long key) {
        Set<UUID> ids = chunkIndex.get(key);
        if (ids == null) {
            return;
        }
        Iterator<UUID> it = ids.iterator();
        while (it.hasNext()) {
            PressureNetwork net = networks.get(it.next());
            if (net == null || !net.hasNodeInChunk(key)) {
                it.remove();
                continue;
            }
            net.markChunkLoaded(key);
        }
        if (ids.isEmpty()) {
            chunkIndex.remove(key);
        } else {
            pendingVerify.add(key);
        }
    }

    /** После чтения с диска часть чанков уже может быть загружена, а события загрузки до нас не дошли. */
    private void refreshLoadedChunks() {
        ServerLevel lvl = level;
        if (lvl == null || chunkIndex.isEmpty()) {
            return;
        }
        LongArrayList keys = new LongArrayList(chunkIndex.keySet());
        for (int i = 0; i < keys.size(); i++) {
            long key = keys.getLong(i);
            if (lvl.getChunkSource().hasChunk(ChunkPos.getX(key), ChunkPos.getZ(key))) {
                markChunkLoaded(key);
            }
        }
    }

    // ------------------------------------------------------------------ тик

    public void tick() {
        if (level == null) {
            return;
        }
        tickCounter++;
        bfsBudget = PressureConstants.BFS_BUDGET_PER_TICK;

        verifyPendingChunks();
        stepJobs();
        processQueue();
        stepNetworks();

        if (changed) {
            changed = false;
            setDirty();
        }
    }

    /**
     * События разбираются строго по порядку. Если событие затрагивает сеть, у которой идёт обход графа,
     * оно откладывается вместе со всеми следующими (порядок не нарушается) и повторяется на следующем тике.
     */
    private void processQueue() {
        if (queue.isEmpty()) {
            return;
        }
        List<TopologyEvent> deferred = new ArrayList<>();
        boolean blocked = false;
        int count = queue.size();
        for (int i = 0; i < count; i++) {
            TopologyEvent event = queue.pollFirst();
            if (event == null) {
                break;
            }
            if (blocked) {
                deferred.add(event);
                continue;
            }
            boolean handled = switch (event.type()) {
                case PLACED -> handlePlaced(event.pos());
                case REMOVED -> handleRemoved(event.pos());
            };
            if (!handled) {
                deferred.add(event);
                blocked = true;
            }
        }
        for (int i = deferred.size() - 1; i >= 0; i--) {
            queue.addFirst(deferred.get(i));
        }
        changed = true;
    }

    private void stepNetworks() {
        ServerLevel lvl = level;
        if (lvl == null) {
            return;
        }
        for (PressureNetwork net : networks.values()) {
            if (net.getState() != PressureNetwork.State.ACTIVE) {
                continue;
            }
            boolean forced = net.consumeForceStep();
            boolean due = Math.floorMod(tickCounter + net.getId().hashCode(),
                    (long) PressureConstants.RECALC_INTERVAL_TICKS) == 0;
            if (!forced && !due && !net.isCachesDirty()) {
                continue;
            }
            if (net.isCachesDirty()) {
                refreshCaches(net);
            }
            long elapsed = tickCounter - net.getLastStepTick();
            int dt = (int) Math.max(1, Math.min(PressureConstants.RECALC_INTERVAL_TICKS, elapsed));
            machineScratch.clear();
            for (BlockPos machinePos : net.getMachines()) {
                if (handlerAt(machinePos) instanceof IPressureMachine machine) {
                    machineScratch.add(machine);
                }
            }
            net.recalculate(dt, machineScratch);
            net.setLastStepTick(tickCounter);
            changed = true;
            applyStepEffects(lvl, net);
        }
    }

    /** Пересчёт кэшей сети: сумма утечек, слабейший узел и пределы; заодно обновляет флаг sealed у узлов. */
    private void refreshCaches(PressureNetwork net) {
        double leakSum = 0.0;
        float minBurst = Float.MAX_VALUE;
        float minVacuum = -Float.MAX_VALUE;
        BlockPos weakest = null;
        for (BlockPos pos : net.getBlocks()) {
            IPressureHandler h = handlerAt(pos);
            if (h == null) {
                continue;
            }
            double k = h.getLeakCoefficient();
            leakSum += k;
            h.setLeaking(k > 0.0);
            float limit = h.getLimit();
            if (limit < minBurst) {
                minBurst = limit;
                weakest = pos;
            }
            minVacuum = Math.max(minVacuum, h.getVacuumLimit());
        }
        net.setCaches(leakSum, minBurst, minVacuum, weakest);
    }

    /** Мировые последствия шага: флаг pressurized, предупреждение, взрыв или схлопывание, конденсат. */
    private void applyStepEffects(ServerLevel lvl, PressureNetwork net) {
        boolean pressurized = Math.abs(net.getPressure()) > 1.0f;
        if (pressurized != net.isPressurizedFlag()) {
            net.setPressurizedFlag(pressurized);
            for (BlockPos pos : net.getBlocks()) {
                IPressureHandler h = handlerAt(pos);
                if (h != null) {
                    h.setPressurized(pressurized);
                }
            }
        }
        float condensate = net.consumeCondensate();
        if (condensate > 0.0f) {
            for (BlockPos pos : net.getBlocks()) {
                IPressureHandler h = handlerAt(pos);
                if (h != null) {
                    h.addCondensate(condensate);
                }
            }
        }
        if (net.getOverloadTicks() > 0) {
            BurstHandler.warn(lvl, net);
        }
        if (net.consumeBurstRequest()) {
            BurstHandler.burst(lvl, this, net);
        } else if (net.consumeImplodeRequest()) {
            BurstHandler.implode(lvl, net);
        }
    }

    /** Узел изменил утечку или износ: пересчитать кэши его сети на ближайшем шаге. */
    public void markNodeDirty(BlockPos pos) {
        PressureNetwork net = getNetworkAt(pos);
        if (net != null) {
            net.markCachesDirty();
        }
    }

    // ------------------------------------------------------------------ установка узла

    /** @return false, если событие надо отложить. */
    private boolean handlePlaced(BlockPos pos) {
        if (nodeIndex.containsKey(pos)) {
            return true;
        }
        IPressureHandler self = handlerAt(pos);
        if (self == null) {
            return true; // блок исчез до разбора очереди
        }

        List<UUID> adjacent = new ArrayList<>(6);
        Set<UUID> seen = new LinkedHashSet<>();
        for (Direction dir : Direction.values()) {
            UUID neighborNet = nodeIndex.get(pos.relative(dir));
            if (neighborNet != null && connected(pos, dir) && seen.add(neighborNet)) {
                adjacent.add(neighborNet);
            }
        }
        for (UUID id : adjacent) {
            if (jobs.containsKey(id)) {
                return false;
            }
        }
        adjacent.sort(Comparator.naturalOrder()); // детерминированный порядок слияния (A.3.2)

        PressureNetwork target;
        if (adjacent.isEmpty()) {
            target = new PressureNetwork(UUID.randomUUID());
            target.setLastStepTick(tickCounter);
            networks.put(target.getId(), target);
        } else {
            int total = 1;
            for (UUID id : adjacent) {
                PressureNetwork net = networks.get(id);
                total += net == null ? 0 : net.getBlockCount();
            }
            if (total > PressureConstants.MAX_BLOCKS_PER_NETWORK) {
                self.onConnectionRefused(); // A.3.5: соединение отклонено
                return true;
            }
            target = networks.get(adjacent.get(0));
            if (target == null) {
                return true;
            }
            for (int i = 1; i < adjacent.size(); i++) {
                PressureNetwork other = networks.remove(adjacent.get(i));
                if (other == null) {
                    continue;
                }
                target.merge(other);
                reindexInto(other, target);
            }
        }

        target.addNode(pos, self.getVolume(), self.getSavedMass(), self instanceof IPressureMachine);
        nodeIndex.put(pos.immutable(), target.getId());
        indexChunk(pos, target.getId());
        target.requestStep();
        self.onNetworkChanged(target);
        return true;
    }

    // ------------------------------------------------------------------ слом узла

    /** @return false, если событие надо отложить. */
    private boolean handleRemoved(BlockPos pos) {
        UUID id = nodeIndex.get(pos);
        if (id == null) {
            return true;
        }
        if (jobs.containsKey(id)) {
            return false;
        }
        nodeIndex.remove(pos);
        PressureNetwork net = networks.get(id);
        if (net == null) {
            return true;
        }

        net.removeNode(pos); // доля слома улетает в воздух, давление остатка прежнее (A.3.3)
        if (net.isEmpty()) {
            networks.remove(id);
            return true;
        }
        if (net.getState() == PressureNetwork.State.SLEEPING && net.getUnloadedChunks().isEmpty()) {
            net.setState(PressureNetwork.State.ACTIVE);
        }
        net.requestStep();

        // Листовой узел (не больше одного соседа в сети) не может разорвать граф.
        int linked = 0;
        for (Direction dir : Direction.values()) {
            if (net.contains(pos.relative(dir))) {
                linked++;
            }
        }
        if (linked > 1) {
            startSplitJob(net);
        }
        return true;
    }

    // ------------------------------------------------------------------ обход графа (BFS с бюджетом)

    private static final class SplitJob {
        final PressureNetwork network;
        final Set<BlockPos> unvisited;
        final Deque<BlockPos> frontier = new ArrayDeque<>();
        final List<List<BlockPos>> components = new ArrayList<>();
        List<BlockPos> current = new ArrayList<>();

        SplitJob(PressureNetwork network) {
            this.network = network;
            this.unvisited = new HashSet<>(network.getBlocks());
        }
    }

    private void startSplitJob(PressureNetwork net) {
        SplitJob job = new SplitJob(net);
        net.setState(PressureNetwork.State.REBUILDING);
        jobs.put(net.getId(), job);
        stepJob(job);
    }

    private void stepJobs() {
        if (jobs.isEmpty()) {
            return;
        }
        for (SplitJob job : new ArrayList<>(jobs.values())) {
            if (bfsBudget <= 0) {
                break;
            }
            stepJob(job);
        }
        changed = true;
    }

    /** Обходит граф в пределах оставшегося бюджета тика. @return true, если задача завершена. */
    private boolean stepJob(SplitJob job) {
        while (true) {
            if (job.frontier.isEmpty()) {
                if (!job.current.isEmpty()) {
                    job.components.add(job.current);
                    job.current = new ArrayList<>();
                }
                if (job.unvisited.isEmpty()) {
                    finishJob(job);
                    return true;
                }
                Iterator<BlockPos> it = job.unvisited.iterator();
                BlockPos seed = it.next();
                it.remove();
                job.frontier.add(seed);
            }
            if (bfsBudget <= 0) {
                return false;
            }
            BlockPos pos = job.frontier.poll();
            if (pos == null) {
                continue;
            }
            job.current.add(pos);
            bfsBudget--;
            for (Direction dir : Direction.values()) {
                BlockPos next = pos.relative(dir);
                if (job.unvisited.contains(next) && connected(pos, dir)) {
                    job.unvisited.remove(next);
                    job.frontier.add(next);
                }
            }
        }
    }

    private void finishJob(SplitJob job) {
        PressureNetwork net = job.network;
        jobs.remove(net.getId());

        if (job.components.size() <= 1) {
            net.setState(restingState(net));
            return;
        }
        unindexChunks(net);
        List<PressureNetwork> parts = net.split(job.components);
        for (PressureNetwork part : parts) {
            networks.put(part.getId(), part);
            indexNetwork(part);
            part.setState(restingState(part));
            part.setLastStepTick(tickCounter);
            for (BlockPos p : part.getBlocks()) {
                IPressureHandler h = handlerAt(p);
                if (h != null) {
                    h.onNetworkChanged(part);
                }
            }
        }
        changed = true;
    }

    private static PressureNetwork.State restingState(PressureNetwork net) {
        return net.getUnloadedChunks().isEmpty() ? PressureNetwork.State.ACTIVE : PressureNetwork.State.SLEEPING;
    }

    /** После загрузки чанка проверяем, не исчезли ли узлы, пока чанк был выгружен (например, правкой мира). */
    private void verifyPendingChunks() {
        if (pendingVerify.isEmpty() || level == null) {
            return;
        }
        LongArrayList chunks = new LongArrayList(pendingVerify);
        pendingVerify.clear();
        for (int i = 0; i < chunks.size(); i++) {
            long key = chunks.getLong(i);
            Set<UUID> ids = chunkIndex.get(key);
            if (ids == null) {
                continue;
            }
            for (UUID id : new ArrayList<>(ids)) {
                PressureNetwork net = networks.get(id);
                if (net == null) {
                    continue;
                }
                for (BlockPos pos : new ArrayList<>(net.getBlocks())) {
                    if (ChunkPos.asLong(pos) == key && level.isLoaded(pos) && handlerAt(pos) == null) {
                        onRemoved(pos);
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------------ связность и индексы

    @Nullable IPressureHandler handlerAt(BlockPos pos) {
        ServerLevel lvl = level;
        if (lvl == null || !lvl.isLoaded(pos)) {
            return null;
        }
        return lvl.getCapability(PressureCapabilities.PRESSURE, pos, null);
    }

    /**
     * Соединены ли узел {@code a} и его сосед в направлении {@code dir}: обе стороны должны разрешать
     * соединение через свои грани. Если один из блоков в выгруженном чанке, доверяем сохранённому графу
     * (оба узла уже в одной сети).
     */
    boolean connected(BlockPos a, Direction dir) {
        ServerLevel lvl = level;
        BlockPos b = a.relative(dir);
        if (lvl != null && lvl.isLoaded(a) && lvl.isLoaded(b)) {
            IPressureHandler ha = handlerAt(a);
            IPressureHandler hb = handlerAt(b);
            return ha != null && hb != null
                    && ha.canConnect(dir)
                    && hb.canConnect(dir.getOpposite());
        }
        UUID ia = nodeIndex.get(a);
        UUID ib = nodeIndex.get(b);
        return ia != null && ia.equals(ib);
    }

    private void indexChunk(BlockPos pos, UUID id) {
        chunkIndex.computeIfAbsent(ChunkPos.asLong(pos), k -> new HashSet<>()).add(id);
    }

    private void indexNetwork(PressureNetwork net) {
        for (BlockPos p : net.getBlocks()) {
            nodeIndex.put(p, net.getId());
            indexChunk(p, net.getId());
        }
    }

    /** Переносит индексы поглощённой сети на целевую. */
    private void reindexInto(PressureNetwork absorbed, PressureNetwork target) {
        for (BlockPos p : absorbed.getBlocks()) {
            nodeIndex.put(p, target.getId());
            indexChunk(p, target.getId());
        }
        unindexChunks(absorbed);
    }

    private void unindexChunks(PressureNetwork net) {
        LongIterator it = net.getNodeChunks().iterator();
        while (it.hasNext()) {
            long key = it.nextLong();
            Set<UUID> ids = chunkIndex.get(key);
            if (ids != null) {
                ids.remove(net.getId());
                if (ids.isEmpty()) {
                    chunkIndex.remove(key);
                }
            }
        }
    }

    // ------------------------------------------------------------------ SavedData

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider registries) {
        ListTag list = new ListTag();
        for (PressureNetwork net : networks.values()) {
            list.add(net.save());
        }
        tag.put("networks", list);
        return tag;
    }

    public static PressureManager load(CompoundTag tag, HolderLookup.Provider registries) {
        PressureManager manager = new PressureManager();
        ListTag list = tag.getList("networks", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            PressureNetwork net = PressureNetwork.load(list.getCompound(i));
            if (net.isEmpty()) {
                continue;
            }
            net.markAllUnloaded();
            manager.networks.put(net.getId(), net);
            manager.indexNetwork(net);
        }
        return manager;
    }
}
