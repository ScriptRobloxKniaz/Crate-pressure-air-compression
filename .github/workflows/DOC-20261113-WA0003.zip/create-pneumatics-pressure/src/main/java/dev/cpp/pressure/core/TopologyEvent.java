package dev.cpp.pressure.core;

import net.minecraft.core.BlockPos;

/** Топологическое событие: разбирается в начале серверного тика строго в порядке поступления (A.2). */
public record TopologyEvent(Type type, BlockPos pos) {
    public enum Type {
        /** Узел установлен или загружен без записи в индексе. */
        PLACED,
        /** Узел удалён (слом, замена блока, удаление BE). */
        REMOVED
    }
}
