package dev.cpp.client;

import dev.cpp.network.ProbeResult;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

/** Только клиент: кладёт ответ в кэш оверлея и, если запрос был от манометра, печатает его в чат. */
public final class ClientProbeHandler {
    private ClientProbeHandler() {}

    public static void show(ProbeResult r) {
        ClientPressureCache.put(r);
        if (!r.chat()) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            return;
        }
        if (!r.found()) {
            mc.player.displayClientMessage(Component.literal(
                    "[CPP] " + r.pos().toShortString() + ": блок не подключён к сети давления"), false);
            return;
        }
        mc.player.displayClientMessage(Component.literal(String.format(
                "[CPP] Сеть у %s: P = %.1f PSI, V = %d, M = %.3f, узлов = %d, T = %.0f °C, состояние %s",
                r.pos().toShortString(), r.pressure(), r.volume(), r.mass(), r.nodes(),
                r.temperature(), r.networkState())), false);
    }
}
