package dev.cpp.block;

import com.mojang.serialization.MapCodec;
import dev.cpp.blockentity.PressureBlockEntity;
import dev.cpp.pressure.api.IPressureHandler;
import dev.cpp.pressure.api.IPressurePort;
import dev.cpp.pressure.core.PipeTier;
import dev.cpp.pressure.core.PressureManager;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

import java.util.EnumMap;
import java.util.Map;

/**
 * Базовый блок трубы давления. BlockState хранит состояние шести граней (куда может течь воздух)
 * и флаг pressurized. Узел сети регистрируется в {@link PressureBlockEntity#onLoad()}, а исчезновение блока
 * сообщается менеджеру из {@link #onRemove}.
 *
 * <p>Заглушки: модель берётся из ванильного куба (см. assets), форма — крест из балок по состоянию граней.
 */
public abstract class AbstractPressurePipeBlock extends BaseEntityBlock {

    public static final EnumProperty<PipeConnection> NORTH = EnumProperty.create("connected_north", PipeConnection.class);
    public static final EnumProperty<PipeConnection> SOUTH = EnumProperty.create("connected_south", PipeConnection.class);
    public static final EnumProperty<PipeConnection> EAST = EnumProperty.create("connected_east", PipeConnection.class);
    public static final EnumProperty<PipeConnection> WEST = EnumProperty.create("connected_west", PipeConnection.class);
    public static final EnumProperty<PipeConnection> UP = EnumProperty.create("connected_up", PipeConnection.class);
    public static final EnumProperty<PipeConnection> DOWN = EnumProperty.create("connected_down", PipeConnection.class);
    public static final BooleanProperty PRESSURIZED = BooleanProperty.create("pressurized");
    /** false, если у узла есть утечка (рисуются частицы и играет шипение). */
    public static final BooleanProperty SEALED = BooleanProperty.create("sealed");

    private static final Map<Direction, EnumProperty<PipeConnection>> BY_DIRECTION = new EnumMap<>(Direction.class);

    static {
        BY_DIRECTION.put(Direction.NORTH, NORTH);
        BY_DIRECTION.put(Direction.SOUTH, SOUTH);
        BY_DIRECTION.put(Direction.EAST, EAST);
        BY_DIRECTION.put(Direction.WEST, WEST);
        BY_DIRECTION.put(Direction.UP, UP);
        BY_DIRECTION.put(Direction.DOWN, DOWN);
    }

    private static final VoxelShape CORE = Block.box(5, 5, 5, 11, 11, 11);
    private static final VoxelShape[] ARMS = new VoxelShape[6];
    private static final VoxelShape[] SHAPES = new VoxelShape[64];

    static {
        ARMS[Direction.DOWN.get3DDataValue()] = Block.box(5, 0, 5, 11, 5, 11);
        ARMS[Direction.UP.get3DDataValue()] = Block.box(5, 11, 5, 11, 16, 11);
        ARMS[Direction.NORTH.get3DDataValue()] = Block.box(5, 5, 0, 11, 11, 5);
        ARMS[Direction.SOUTH.get3DDataValue()] = Block.box(5, 5, 11, 11, 11, 16);
        ARMS[Direction.WEST.get3DDataValue()] = Block.box(0, 5, 5, 5, 11, 11);
        ARMS[Direction.EAST.get3DDataValue()] = Block.box(11, 5, 5, 16, 11, 11);
        for (int mask = 0; mask < SHAPES.length; mask++) {
            VoxelShape shape = CORE;
            for (int i = 0; i < 6; i++) {
                if ((mask & (1 << i)) != 0) {
                    shape = Shapes.or(shape, ARMS[i]);
                }
            }
            SHAPES[mask] = shape;
        }
    }

    protected AbstractPressurePipeBlock(Properties properties) {
        super(properties);
        BlockState state = stateDefinition.any().setValue(PRESSURIZED, false).setValue(SEALED, true);
        for (EnumProperty<PipeConnection> property : BY_DIRECTION.values()) {
            state = state.setValue(property, PipeConnection.NONE);
        }
        registerDefaultState(state);
    }

    /** Класс трубы (материал). */
    public abstract PipeTier tier();

    @Override
    protected abstract MapCodec<? extends BaseEntityBlock> codec();

    // ------------------------------------------------------------------ состояние

    public static EnumProperty<PipeConnection> property(Direction dir) {
        return BY_DIRECTION.get(dir);
    }

    public static PipeConnection connectionOf(BlockState state, Direction dir) {
        return state.getValue(BY_DIRECTION.get(dir));
    }

    /**
     * Новое состояние грани по соседу. Узел-сосед (труба или порт машины) даёт PIPE. Если соседа не стало,
     * бывшее соединение превращается в открытый порт PORT (большая утечка, A.5), заглушка остаётся заглушкой.
     */
    protected PipeConnection connectionFor(BlockState neighborState, Direction towardNeighbor, PipeConnection current) {
        Block neighbor = neighborState.getBlock();
        if (neighbor instanceof AbstractPressurePipeBlock) {
            return PipeConnection.PIPE;
        }
        if (neighbor instanceof IPressurePort port
                && port.hasPressurePort(neighborState, towardNeighbor.getOpposite())) {
            return PipeConnection.PIPE;
        }
        return switch (current) {
            case PIPE, PORT -> PipeConnection.PORT;
            case PLUG -> PipeConnection.PLUG;
            case NONE -> PipeConnection.NONE;
        };
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(NORTH, SOUTH, EAST, WEST, UP, DOWN, PRESSURIZED, SEALED);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        BlockState state = defaultBlockState();
        Level level = context.getLevel();
        BlockPos pos = context.getClickedPos();
        for (Direction dir : Direction.values()) {
            state = state.setValue(BY_DIRECTION.get(dir), connectionFor(level.getBlockState(pos.relative(dir)), dir, PipeConnection.NONE));
        }
        return state;
    }

    @Override
    protected BlockState updateShape(BlockState state, Direction direction, BlockState neighborState,
                                     LevelAccessor level, BlockPos pos, BlockPos neighborPos) {
        EnumProperty<PipeConnection> property = BY_DIRECTION.get(direction);
        PipeConnection current = state.getValue(property);
        PipeConnection next = connectionFor(neighborState, direction, current);
        if (next == current) {
            return state;
        }
        // Соседа сломали: затяжка этой грани сбрасывается (A.5, п. 5), грань становится открытым портом.
        if (current == PipeConnection.PIPE && next == PipeConnection.PORT && !level.isClientSide()
                && level.getBlockEntity(pos) instanceof IPressureHandler handler) {
            handler.setSealLevel(direction, 0);
        }
        return state.setValue(property, next);
    }

    /** Частицы и шипение утечки (клиент): только когда сеть под давлением и у узла есть утечка. */
    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        if (state.getValue(SEALED) || !state.getValue(PRESSURIZED)) {
            return;
        }
        if (random.nextInt(3) == 0) {
            Direction face = Direction.getRandom(random);
            double x = pos.getX() + 0.5 + face.getStepX() * 0.45;
            double y = pos.getY() + 0.5 + face.getStepY() * 0.45;
            double z = pos.getZ() + 0.5 + face.getStepZ() * 0.45;
            level.addParticle(ParticleTypes.CLOUD, x, y, z,
                    face.getStepX() * 0.06 + (random.nextDouble() - 0.5) * 0.02,
                    face.getStepY() * 0.06 + (random.nextDouble() - 0.5) * 0.02,
                    face.getStepZ() * 0.06 + (random.nextDouble() - 0.5) * 0.02);
        }
        if (random.nextInt(24) == 0) {
            level.playLocalSound(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5,
                    SoundEvents.FIRE_EXTINGUISH, SoundSource.BLOCKS, 0.15f, 1.7f, false);
        }
    }

    // ------------------------------------------------------------------ форма и рендер

    @Override
    protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        int mask = 0;
        for (Direction dir : Direction.values()) {
            if (connectionOf(state, dir) != PipeConnection.NONE) {
                mask |= 1 << dir.get3DDataValue();
            }
        }
        return SHAPES[mask];
    }

    /** BaseEntityBlock по умолчанию невидим (ENTITYBLOCK_ANIMATED), нужна обычная блочная модель. */
    @Override
    protected RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    // ------------------------------------------------------------------ BlockEntity и жизненный цикл

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new PressureBlockEntity(pos, state);
    }

    /**
     * Блок реально убран или заменён (слом, взрыв, поршень, /setblock). Выгрузка чанка сюда не попадает,
     * поэтому спящие сети не теряют узлы.
     */
    @Override
    protected void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
        if (!state.is(newState.getBlock()) && level instanceof ServerLevel serverLevel) {
            PressureManager.get(serverLevel).onRemoved(pos);
        }
        super.onRemove(state, level, pos, newState, movedByPiston);
    }
}
