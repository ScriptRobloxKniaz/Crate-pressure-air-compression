package dev.cpp.item;

import dev.cpp.pressure.api.IPressureHandler;
import dev.cpp.pressure.core.PressureManager;
import dev.cpp.pressure.core.PressureNetwork;
import dev.cpp.pressure.core.PressureTools;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

/**
 * Гаечный ключ для пневматики (раздел 5.1). ПКМ — затянуть все стыки блока, Shift+ПКМ — всю прямую секцию
 * вдоль грани, по которой кликнули. На сети выше рабочего диапазона затяжка срывается с шансом 20 %
 * (износ узла растёт, стык не затягивается).
 */
public class PneumaticWrenchItem extends Item {

    private static final float SLIP_CHANCE = 0.2f;
    private static final float SLIP_WEAR = 2.0f;

    public PneumaticWrenchItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        if (level.isClientSide) {
            return InteractionResult.sidedSuccess(true);
        }
        Player player = context.getPlayer();
        if (!(level instanceof ServerLevel serverLevel) || player == null) {
            return InteractionResult.PASS;
        }
        IPressureHandler handler = PressureTools.handler(level, context.getClickedPos());
        if (handler == null) {
            return InteractionResult.PASS;
        }

        PressureNetwork net = PressureManager.get(serverLevel).getNetworkAt(context.getClickedPos());
        if (net != null && net.getPressure() > handler.getWorkingMax() && level.random.nextFloat() < SLIP_CHANCE) {
            handler.applyWear(SLIP_WEAR);
            player.displayClientMessage(Component.translatable("cpp.wrench.slipped"), true);
            level.playSound(null, context.getClickedPos(), SoundEvents.CHAIN_HIT, SoundSource.PLAYERS, 0.8f, 0.7f);
            damage(context, player);
            return InteractionResult.CONSUME;
        }

        int tightened = player.isShiftKeyDown()
                ? PressureTools.tightenRun(level, context.getClickedPos(), context.getClickedFace())
                : PressureTools.tightenBlock(level, context.getClickedPos());
        if (tightened > 0) {
            player.displayClientMessage(Component.translatable("cpp.wrench.tightened", tightened), true);
            level.playSound(null, context.getClickedPos(), SoundEvents.CHAIN_PLACE, SoundSource.PLAYERS, 1.0f, 1.3f);
            damage(context, player);
        } else {
            player.displayClientMessage(Component.translatable("cpp.wrench.nothing"), true);
        }
        return InteractionResult.CONSUME;
    }

    private static void damage(UseOnContext context, Player player) {
        context.getItemInHand().hurtAndBreak(1, (LivingEntity) player, LivingEntity.getSlotForHand(context.getHand()));
    }
}
