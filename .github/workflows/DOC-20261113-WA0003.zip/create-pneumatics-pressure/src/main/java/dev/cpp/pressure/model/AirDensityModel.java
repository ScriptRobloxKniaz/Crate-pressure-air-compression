package dev.cpp.pressure.model;

/** Плотность воздуха ρ (раздел 2.8). Чистая математика без зависимостей от Minecraft. */
public final class AirDensityModel {
    private AirDensityModel() {}

    public static final float SLOPE = 0.002f;
    public static final float MIN = 0.4f;
    public static final float MAX = 1.15f;
    public static final float NETHER = 1.3f;
    public static final float END = 0.3f;

    /** Верхний мир: ρ = 1 − (Y − 64) × 0.002, в пределах 0.4..1.15. */
    public static float overworld(int y) {
        float rho = 1.0f - (y - 64) * SLOPE;
        return Math.max(MIN, Math.min(MAX, rho));
    }
}
