package dev.cpp.network;

import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

/** Регистрация пакетов (PayloadRegistrar). Версия протокола повышается при изменении формата. */
public final class CppNetwork {
    private CppNetwork() {}

    public static final String PROTOCOL_VERSION = "1";

    public static void registerPayloads(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar(PROTOCOL_VERSION);
        registrar.playToServer(ProbeRequest.TYPE, ProbeRequest.STREAM_CODEC, ProbeRequest::handle);
        registrar.playToClient(ProbeResult.TYPE, ProbeResult.STREAM_CODEC, ProbeResult::handle);
    }
}
