package dev.cpp.pressure.model;

/** Перегрузка и взрывы (раздел 2.4). Чистая математика: мировые эффекты выполняет BurstHandler. */
public final class BurstModel {
    private BurstModel() {}

    public static final int OVERLOAD_TICKS = 60;
    public static final float POWER_BASE = 1.5f;
    public static final float POWER_PER_100 = 0.5f;
    public static final float CAP_PIPE = 3.0f;
    public static final float CAP_RECEIVER = 4.0f;
    public static final float CAP_COMPRESSOR = 2.0f;
    public static final int CHAIN_LIMIT = 12;
    public static final double CHAIN_HALF_DISTANCE = 2.0;

    /** Сила взрыва: 1.5 + 0.5 × (превышение/100), не выше потолка узла. */
    public static float power(float pressure, float limit, float cap) {
        float over = Math.max(0.0f, pressure - limit);
        return Math.min(cap, POWER_BASE + POWER_PER_100 * over / 100.0f);
    }

    /** Вероятность, что соседняя изношенная секция на расстоянии d сегментов тоже лопнет: p = 0.5^(d/2). */
    public static double chainProbability(int distance) {
        if (distance <= 0 || distance > CHAIN_LIMIT) {
            return 0.0;
        }
        return Math.pow(0.5, distance / CHAIN_HALF_DISTANCE);
    }

    /**
     * Счётчик перегрузки: растёт на dt, пока давление вне допустимого диапазона, и убывает вдвое быстрее
     * (по 10 за шаг из 5 тиков), когда вернулось в норму.
     */
    public static int updateOverload(int ticks, boolean over, int dtTicks) {
        return over ? Math.min(OVERLOAD_TICKS, ticks + dtTicks) : Math.max(0, ticks - 2 * dtTicks);
    }

    public static boolean isOverloaded(float p, float burstLimit, float vacuumLimit) {
        return p > burstLimit || p < vacuumLimit;
    }
}
