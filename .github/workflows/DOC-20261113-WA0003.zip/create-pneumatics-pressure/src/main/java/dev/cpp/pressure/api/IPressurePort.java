package dev.cpp.pressure.api;

import net.minecraft.core.Direction;
import net.minecraft.world.level.block.state.BlockState;

/** Реализуется блоками-машинами: через какие грани к ним подключаются трубы давления. */
public interface IPressurePort {
    boolean hasPressurePort(BlockState state, Direction face);
}
