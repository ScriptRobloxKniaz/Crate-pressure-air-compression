package dev.cpp.pressure.model;

/**
 * Физика компрессора по разделам 3.1, 3.4 и 2.8 (константы из раздела 11).
 * Класс хранит только температуру; скорость вращения и давление передаются снаружи.
 * Отрицательная скорость вала означает режим вакуумного насоса.
 */
public final class CompressorModel {

    public static final float SU_PER_RPM = 6.0f;
    public static final float STRESS_FLOOR = 0.5f;
    public static final float MASS_PER_RPM = 0.2f;
    public static final float MIN_RPM = 16.0f;
    public static final float MAX_RPM = 256.0f;
    public static final float HEAT_COEF = 0.02f;
    public static final float COOL_COEF = 0.012f;
    public static final float WARN_TEMP = 150.0f;
    public static final float BURST_TEMP = 200.0f;
    public static final float AMBIENT = 20.0f;
    /** Предел вакуума насоса, PSI (по модулю). */
    public static final float VACUUM_PMAX = 100.0f;

    /** Throttle снимается с гистерезисом, чтобы производительность не дребезжала на пороге 150 °C. */
    public static final float THROTTLE_RELEASE_TEMP = 140.0f;

    private float temperature = AMBIENT;
    private boolean throttled;

    public float getTemperature() { return temperature; }
    public void setTemperature(float t) { this.temperature = t; refreshThrottle(); }
    public boolean isOverheating() { return throttled; }
    public boolean isBurstTemperature() { return temperature >= BURST_TEMP; }

    /** Рабочие обороты: 0, если ниже минимума; ограничены сверху. */
    public static double effectiveRpm(double shaftRpm) {
        double rpm = Math.abs(shaftRpm);
        return rpm < MIN_RPM ? 0.0 : Math.min(rpm, MAX_RPM);
    }

    /**
     * Шаг 1 из A.2: масса, добавленная (или, для вакуума, убранная) за шаг.
     * Нагнетание: 0.2 × RPM × ρ × (1 − P₀/Pmax) × dt. При перегреве ≥ 150 °C производительность вдвое ниже.
     */
    public double produce(double shaftRpm, float rho, float p0, CompressorTier tier, int dtTicks) {
        double rpm = effectiveRpm(shaftRpm);
        if (rpm <= 0.0) {
            return 0.0;
        }
        double dtSec = dtTicks / 20.0;
        double heatFactor = isOverheating() ? 0.5 : 1.0;
        if (shaftRpm >= 0.0) {
            double headroom = Math.max(0.0, 1.0 - p0 / tier.getPmax());
            return MASS_PER_RPM * rpm * rho * headroom * heatFactor * dtSec;
        }
        double headroom = Math.max(0.0, 1.0 - Math.abs(Math.min(p0, 0.0f)) / VACUUM_PMAX);
        return -MASS_PER_RPM * rpm * rho * headroom * heatFactor * dtSec;
    }

    /**
     * Нагрузка на вал, су на 1 RPM: 6 × (1 − 0.5·x), x = |P|/Pmax. У Pmax остаётся 50 % номинала,
     * то есть компрессор не вращается бесплатно (раздел 3.4, п. 4).
     */
    public static float stressPerRpm(float p, CompressorTier tier, boolean vacuum) {
        float pmax = vacuum ? VACUUM_PMAX : tier.getPmax();
        float x = Math.max(0.0f, Math.min(1.0f, Math.abs(vacuum ? Math.min(p, 0f) : p) / pmax));
        return SU_PER_RPM * (1.0f - (1.0f - STRESS_FLOOR) * x);
    }

    /**
     * Шаг 4 из A.2 (после утечки): T += (0.02·RPM·√(P₁/100) − 0.012·(T − T_среды) − внешнее охлаждение)·dt.
     *
     * @param externalCooling внешнее охлаждение, °C/сек (вода Create 100 mB/сек — 1.5, вентилятор — 0.5)
     */
    public void updateHeat(double shaftRpm, float p1, float ambient, float externalCooling, int dtTicks) {
        double rpm = effectiveRpm(shaftRpm);
        double heat = HEAT_COEF * rpm * Math.sqrt(Math.max(0.0f, p1) / 100.0);
        double cooling = COOL_COEF * (temperature - ambient) + externalCooling;
        temperature += (float) ((heat - cooling) * (dtTicks / 20.0));
        if (temperature < ambient) {
            temperature = ambient;
        }
        refreshThrottle();
    }

    private void refreshThrottle() {
        if (temperature >= WARN_TEMP) {
            throttled = true;
        } else if (temperature < THROTTLE_RELEASE_TEMP) {
            throttled = false;
        }
    }
}
