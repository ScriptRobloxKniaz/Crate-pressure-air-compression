package dev.cpp.blockentity;

import com.simibubi.create.content.kinetics.base.GeneratingKineticBlockEntity;
import dev.cpp.block.PneumaticMotorBlock;
import dev.cpp.goggles.PressureGoggleLines;
import dev.cpp.pressure.api.IPressureHandler;
import dev.cpp.pressure.api.IPressureMachine;
import dev.cpp.pressure.core.PipeTier;
import dev.cpp.pressure.core.PressureManager;
import dev.cpp.pressure.model.MotorModel;
import dev.cpp.registry.ModRegistries;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;

import java.util.List;

/**
 * Пневматический двигатель (Pressure → Kinetic): RPM = min(256, 4.5·√P), расход 0.075 ед./RPM, 2.0 су/RPM.
 * Если воздуха не хватает, обороты падают пропорционально выданной доле (A.2, шаг 2).
 */
public class PneumaticMotorBlockEntity extends GeneratingKineticBlockEntity implements IPressureHandler, IPressureMachine {

    private static final int VOLUME = 2;
    private static final PipeTier LIMIT_CLASS = PipeTier.IRON;

    private final PressureNodeState node = new PressureNodeState();
    private float generatedRpm;
    private double targetRpm;

    public PneumaticMotorBlockEntity(BlockPos pos, BlockState state) {
        this(ModRegistries.MOTOR.get(), pos, state);
    }

    public PneumaticMotorBlockEntity(BlockEntityType<?> type, BlockPos pos, BlockState state) {
        super(type, pos, state);
    }

    @Override
    public void initialize() {
        super.initialize();
        if (level instanceof ServerLevel serverLevel) {
            PressureManager.get(serverLevel).onPlaced(worldPosition);
        }
    }

    // ------------------------------------------------------------------ генерация (Create)

    @Override
    public float getGeneratedSpeed() {
        return generatedRpm;
    }

    /** Ёмкость стресса на 1 RPM: 2.0 су (при 64 RPM — 128 су). */
    @Override
    public float calculateAddedStressCapacity() {
        this.lastCapacityProvided = MotorModel.capacityPerRpm();
        return this.lastCapacityProvided;
    }

    // ------------------------------------------------------------------ IPressureMachine

    @Override
    public double demand(float p0, int dtTicks) {
        targetRpm = MotorModel.targetRpm(p0);
        return MotorModel.demand(p0, dtTicks);
    }

    @Override
    public void onSupplied(double fraction) {
        float rpm = Math.round((float) Math.min(MotorModel.MAX_RPM, targetRpm * fraction));
        if (Math.abs(rpm - generatedRpm) >= 1.0f) {
            generatedRpm = rpm;
            updateGeneratedRotation();
        }
    }

    // ------------------------------------------------------------------ NBT

    @Override
    protected void write(CompoundTag compound, HolderLookup.Provider registries, boolean clientPacket) {
        super.write(compound, registries, clientPacket);
        node.write(compound, level, worldPosition);
        compound.putFloat("GeneratedRpm", generatedRpm);
    }

    @Override
    protected void read(CompoundTag compound, HolderLookup.Provider registries, boolean clientPacket) {
        super.read(compound, registries, clientPacket);
        node.read(compound);
        generatedRpm = compound.getFloat("GeneratedRpm");
    }

    // ------------------------------------------------------------------ очки Create

    @Override
    public boolean addToGoggleTooltip(List<Component> tooltip, boolean isPlayerSneaking) {
        super.addToGoggleTooltip(tooltip, isPlayerSneaking);
        PressureGoggleLines.add(tooltip, worldPosition, this, isPlayerSneaking, LIMIT_CLASS.getWorkingMax());
        tooltip.add(PressureGoggleLines.line(Component.translatable("cpp.goggles.motor.rpm",
                PressureGoggleLines.fmt("%.0f", Math.abs(getSpeed()))).withStyle(ChatFormatting.GRAY)));
        return true;
    }

    // ------------------------------------------------------------------ IPressureHandler

    @Override public int getVolume() { return VOLUME; }
    @Override public float getLimit() { return LIMIT_CLASS.getBurstLimit(); }
    @Override public float getWorkingMax() { return LIMIT_CLASS.getWorkingMax(); }
    @Override public float getVacuumLimit() { return LIMIT_CLASS.getVacuumLimit(); }

    @Override
    public boolean canConnect(Direction face) {
        BlockState state = getBlockState();
        return state.getBlock() instanceof PneumaticMotorBlock block && block.hasPressurePort(state, face);
    }

    @Override public int getSealLevel(Direction face) { return node.getSeal(face); }

    @Override
    public void setSealLevel(Direction face, int level) {
        node.setSeal(face, level);
        setChanged();
        notifyLeakChange();
    }

    @Override public boolean isOpenPort(Direction face) { return false; }

    @Override
    public void applyWear(float amount) {
        node.applyWear(amount);
        setChanged();
        notifyLeakChange();
    }

    private void notifyLeakChange() {
        if (level instanceof ServerLevel serverLevel) {
            PressureManager.get(serverLevel).markNodeDirty(worldPosition);
        }
    }

    @Override public double getSavedMass() { return node.getMass(); }
    @Override public float getWear() { return node.getWear(); }
    @Override public float getCondensate() { return node.getCondensate(); }
}
