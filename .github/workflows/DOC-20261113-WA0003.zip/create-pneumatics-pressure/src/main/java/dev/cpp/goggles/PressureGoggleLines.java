package dev.cpp.goggles;

import dev.cpp.client.ClientPressureCache;
import dev.cpp.network.ProbeResult;
import dev.cpp.pressure.api.IPressureHandler;
import dev.cpp.pressure.core.PressureNetwork;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

import java.util.List;
import java.util.Locale;

/** Общие строки подсказки очков Create для всех узлов сети: давление, шкала, объём, затяжка. */
public final class PressureGoggleLines {
    private PressureGoggleLines() {}

    private static final String INDENT = "    ";
    private static final int BAR_WIDTH = 20;
    private static final String[] FACE_LETTERS = {"D", "U", "N", "S", "W", "E"}; // порядок Direction.get3DDataValue()

    public static Component line(Component content) {
        return Component.literal(INDENT).append(content);
    }

    public static String fmt(String pattern, Object value) {
        return String.format(Locale.ROOT, pattern, value);
    }

    /**
     * @param workingMax верхняя граница рабочего диапазона узла (для цвета: зелёный до неё, жёлтый до предела)
     * @return true, если данные уже пришли и можно добавлять строки, специфичные для машины
     */
    public static boolean add(List<Component> tooltip, BlockPos pos, IPressureHandler handler,
                              boolean sneaking, float workingMax) {
        tooltip.add(line(Component.translatable("cpp.goggles.header").withStyle(ChatFormatting.GOLD)));

        ProbeResult data = ClientPressureCache.get(pos);
        if (data == null) {
            tooltip.add(line(Component.translatable("cpp.goggles.waiting").withStyle(ChatFormatting.GRAY)));
            return false;
        }
        if (!data.found()) {
            tooltip.add(line(Component.translatable("cpp.goggles.no_network").withStyle(ChatFormatting.RED)));
            return false;
        }

        float p = data.pressure();
        ChatFormatting color = zoneColor(p, workingMax, handler.getLimit(), handler.getVacuumLimit());
        tooltip.add(line(Component.translatable("cpp.goggles.pressure").withStyle(ChatFormatting.GRAY)
                .append(Component.literal(" " + fmt("%.0f", p) + " PSI").withStyle(color))));
        tooltip.add(line(bar(p, color, handler.getLimit(), handler.getVacuumLimit())));
        tooltip.add(line(Component.translatable("cpp.goggles.stats",
                data.volume(), data.nodes(), fmt("%.2f", data.mass())).withStyle(ChatFormatting.DARK_GRAY)));
        if (data.overload() > 0) {
            float seconds = Math.max(0.0f, (60 - data.overload()) / 20.0f);
            tooltip.add(line(Component.translatable("cpp.goggles.overload", fmt("%.1f", seconds))
                    .withStyle(ChatFormatting.RED, ChatFormatting.BOLD)));
        }
        if (data.networkState() != PressureNetwork.State.ACTIVE) {
            tooltip.add(line(Component.translatable("cpp.goggles.state."
                    + data.networkState().name().toLowerCase(Locale.ROOT)).withStyle(ChatFormatting.YELLOW)));
        }

        if (sneaking) {
            MutableComponent faces = Component.empty();
            boolean any = false;
            for (int i = 0; i < 6; i++) {
                if (!handler.canConnect(Direction.from3DDataValue(i))) {
                    continue;
                }
                int seal = data.seal()[i];
                ChatFormatting c = seal >= 100 ? ChatFormatting.GREEN : seal >= 40 ? ChatFormatting.YELLOW : ChatFormatting.RED;
                faces = faces.append(Component.literal(FACE_LETTERS[i] + " " + seal + "%  ").withStyle(c));
                any = true;
            }
            if (any) {
                tooltip.add(line(Component.translatable("cpp.goggles.seal").withStyle(ChatFormatting.GRAY)
                        .append(" ").append(faces)));
            }
            tooltip.add(line(Component.translatable("cpp.goggles.wear", fmt("%.0f", data.wear())).withStyle(ChatFormatting.GRAY)));
            if (data.condensate() > 0.0f) {
                tooltip.add(line(Component.translatable("cpp.goggles.condensate", fmt("%.1f", data.condensate())).withStyle(ChatFormatting.AQUA)));
            }
        } else {
            tooltip.add(line(Component.translatable("cpp.goggles.hint_sneak").withStyle(ChatFormatting.DARK_GRAY)));
        }
        return true;
    }

    /** Зелёный — рабочий диапазон, жёлтый — зона риска, красный — выше предела; голубой — вакуум. */
    public static ChatFormatting zoneColor(float p, float workingMax, float burstLimit, float vacuumLimit) {
        if (p < 0.0f) {
            return p < vacuumLimit ? ChatFormatting.RED : ChatFormatting.AQUA;
        }
        if (p <= workingMax) {
            return ChatFormatting.GREEN;
        }
        return p <= burstLimit ? ChatFormatting.GOLD : ChatFormatting.RED;
    }

    /** Шкала относительно предела прочности (для вакуума — относительно вакуумного предела). */
    public static Component bar(float p, ChatFormatting color, float burstLimit, float vacuumLimit) {
        float limit = p < 0.0f ? Math.abs(vacuumLimit) : burstLimit;
        float fraction = limit <= 0.0f ? 0.0f : Math.min(1.0f, Math.abs(p) / limit);
        int filled = Math.round(fraction * BAR_WIDTH);
        return Component.literal("\u2588".repeat(filled)).withStyle(color)
                .append(Component.literal("\u2591".repeat(BAR_WIDTH - filled)).withStyle(ChatFormatting.DARK_GRAY));
    }
}
