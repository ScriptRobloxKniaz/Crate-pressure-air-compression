package dev.cpp.pressure.model;

/** Утечки (раздел 2.3). Потеря массы на одну утечку: k × (|P|/100)^1.5 ед./сек. */
public final class LeakModel {
    private LeakModel() {}

    public static final double K_SMALL = 0.3;
    public static final double K_LARGE = 1.0;
    public static final double EXPONENT = 1.5;
    /** Затяжка ниже этого значения даёт малую утечку, %. */
    public static final int SEAL_LEAK_BELOW = 40;
    /** Износ, с которого появляется малая и большая трещина, %. */
    public static final float WEAR_SMALL = 50.0f;
    public static final float WEAR_LARGE = 80.0f;

    /**
     * Масса, ушедшая из сети за шаг. Для давления выше нуля результат положительный (масса убывает),
     * для вакуума отрицательный (воздух втягивается, масса растёт к нулю).
     *
     * @param kSum сумма коэффициентов всех утечек сети
     */
    public static double massLoss(double kSum, float p, int dtTicks) {
        if (kSum <= 0.0) {
            return 0.0;
        }
        double rate = kSum * Math.pow(Math.abs(p) / 100.0, EXPONENT) * (dtTicks / 20.0);
        return p >= 0.0f ? rate : -rate;
    }

    /** Применяет потерю к массе так, чтобы утечка не переводила сеть через атмосферное давление. */
    public static double applyLoss(double mass, double loss) {
        double next = mass - loss;
        if (mass >= 0.0 && next < 0.0) {
            return 0.0;
        }
        if (mass <= 0.0 && next > 0.0) {
            return 0.0;
        }
        return next;
    }
}
