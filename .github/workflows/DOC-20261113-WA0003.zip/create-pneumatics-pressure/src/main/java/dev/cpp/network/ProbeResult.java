package dev.cpp.network;

import dev.cpp.CppMod;
import dev.cpp.pressure.api.IPressureHandler;
import dev.cpp.client.ClientProbeHandler;
import dev.cpp.pressure.core.PressureNetwork;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.neoforged.neoforge.network.handling.IPayloadContext;
import org.jetbrains.annotations.Nullable;

/**
 * Сервер → клиент: сводка по сети в точке плюс данные самого узла (затяжка граней, износ, конденсат).
 * {@code chat = true} — печатать в чат (манометр), иначе только в кэш оверлея очков.
 */
public record ProbeResult(BlockPos pos, boolean found, float pressure, double mass, int volume,
                          int nodes, byte state, float temperature, boolean chat,
                          byte[] seal, float wear, float condensate, byte overload) implements CustomPacketPayload {

    public static final Type<ProbeResult> TYPE = new Type<>(CppMod.id("probe_result"));

    public static final StreamCodec<RegistryFriendlyByteBuf, ProbeResult> STREAM_CODEC =
            StreamCodec.ofMember(ProbeResult::write, ProbeResult::read);

    public static ProbeResult of(BlockPos pos, @Nullable PressureNetwork net,
                                 @Nullable IPressureHandler node, boolean chat) {
        byte[] seal = new byte[6];
        float wear = 0f;
        float condensate = 0f;
        if (node != null) {
            for (int i = 0; i < 6; i++) {
                seal[i] = (byte) node.getSealLevel(Direction.from3DDataValue(i));
            }
            wear = node.getWear();
            condensate = node.getCondensate();
        }
        if (net == null) {
            return new ProbeResult(pos, false, 0f, 0.0, 0, 0, (byte) 0, 0f, chat, seal, wear, condensate, (byte) 0);
        }
        return new ProbeResult(pos, true, net.getPressure(), net.getMass(), net.getVolume(),
                net.getBlockCount(), (byte) net.getState().ordinal(), net.getTemperature(),
                chat, seal, wear, condensate, (byte) net.getOverloadTicks());
    }

    public PressureNetwork.State networkState() {
        PressureNetwork.State[] all = PressureNetwork.State.values();
        return all[Math.floorMod(state, all.length)];
    }

    private void write(RegistryFriendlyByteBuf buf) {
        buf.writeBlockPos(pos);
        buf.writeBoolean(found);
        buf.writeFloat(pressure);
        buf.writeDouble(mass);
        buf.writeVarInt(volume);
        buf.writeVarInt(nodes);
        buf.writeByte(state);
        buf.writeFloat(temperature);
        buf.writeBoolean(chat);
        for (int i = 0; i < 6; i++) {
            buf.writeByte(seal[i]);
        }
        buf.writeFloat(wear);
        buf.writeFloat(condensate);
        buf.writeByte(overload);
    }

    private static ProbeResult read(RegistryFriendlyByteBuf buf) {
        BlockPos pos = buf.readBlockPos();
        boolean found = buf.readBoolean();
        float pressure = buf.readFloat();
        double mass = buf.readDouble();
        int volume = buf.readVarInt();
        int nodes = buf.readVarInt();
        byte state = buf.readByte();
        float temperature = buf.readFloat();
        boolean chat = buf.readBoolean();
        byte[] seal = new byte[6];
        for (int i = 0; i < 6; i++) {
            seal[i] = buf.readByte();
        }
        float wear = buf.readFloat();
        float condensate = buf.readFloat();
        byte overload = buf.readByte();
        return new ProbeResult(pos, found, pressure, mass, volume, nodes, state, temperature,
                chat, seal, wear, condensate, overload);
    }

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    /** Клиентская обработка. ClientProbeHandler подгружается только здесь, на клиенте. */
    public static void handle(ProbeResult result, IPayloadContext context) {
        ClientProbeHandler.show(result);
    }
}
