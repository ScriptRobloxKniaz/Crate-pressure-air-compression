package dev.cpp.pressure.api;

import dev.cpp.pressure.core.PressureNetwork;
import dev.cpp.pressure.model.BurstModel;
import dev.cpp.pressure.model.LeakModel;
import net.minecraft.core.Direction;
import org.jetbrains.annotations.Nullable;

/**
 * Capability узла сети давления (cpp:pressure). Реализуется BlockEntity труб и машин.
 * Все методы вызываются только с серверного потока.
 */
public interface IPressureHandler {
    int MAX_SEAL = 100;

    /** Объём узла V (труба = 1, машина = 2, блок ресивера = 12). */
    int getVolume();

    /** Предел прочности, PSI. Выше него начинается перегрузка (Milestone 3). */
    float getLimit();

    /** Предел по вакууму (отрицательное число, например -30 для меди). */
    float getVacuumLimit();

    /** Может ли узел соединяться с соседом через грань {@code face}. */
    boolean canConnect(Direction face);

    /** Затяжка соединения на грани, 0..100 %. */
    int getSealLevel(Direction face);

    void setSealLevel(Direction face, int level);

    /** Затянуть соединение на {@code amount} процентов с ограничением 0..100. */
    default void tighten(Direction face, int amount) {
        int next = Math.max(0, Math.min(MAX_SEAL, getSealLevel(face) + amount));
        setSealLevel(face, next);
    }

    /** Грань является открытым портом (соединяемая грань без соседа и без заглушки). */
    boolean isOpenPort(Direction face);

    /** Добавить износ (0..100). */
    void applyWear(float amount);

    /** Износ узла, 0..100 (для оверлея и пакета зондирования). */
    default float getWear() {
        return 0.0f;
    }

    /** Конденсат в узле, ед. */
    default float getCondensate() {
        return 0.0f;
    }

    /** Снимок массы узла из NBT (A.1). Используется один раз, когда узел вводится в сеть без истории. */
    double getSavedMass();


    /** Верхняя граница рабочего диапазона узла, PSI (выше — зона риска). */
    default float getWorkingMax() {
        return getLimit() * 0.75f;
    }

    /** Потолок силы взрыва этого узла (труба 3.0, ресивер 4.0, компрессор 2.0). */
    default float getBurstPowerCap() {
        return BurstModel.CAP_PIPE;
    }

    /**
     * Сумма коэффициентов утечек узла (раздел 2.3): открытый порт — большая утечка, соединение с затяжкой
     * ниже 40 % — малая, износ ≥ 50 % / ≥ 80 % — малая / большая трещина.
     */
    default double getLeakCoefficient() {
        double k = 0.0;
        for (Direction face : Direction.values()) {
            if (isOpenPort(face)) {
                k += LeakModel.K_LARGE;
            } else if (canConnect(face) && getSealLevel(face) < LeakModel.SEAL_LEAK_BELOW) {
                k += LeakModel.K_SMALL;
            }
        }
        float wear = getWear();
        if (wear >= LeakModel.WEAR_LARGE) {
            k += LeakModel.K_LARGE;
        } else if (wear >= LeakModel.WEAR_SMALL) {
            k += LeakModel.K_SMALL;
        }
        return k;
    }

    /** Менеджер сообщает, есть ли у узла утечка (для блочного состояния sealed и частиц). */
    default void setLeaking(boolean leaking) {}

    /** Менеджер сообщает, что давление в сети выше атмосферного (блочное состояние pressurized). */
    default void setPressurized(boolean pressurized) {}

    /** Сеть добавляет конденсат узлу (раздел 2.6). */
    default void addCondensate(float amount) {}

    /** Менеджер сообщает узлу, в какой сети он теперь состоит (null — вне сети). */
    default void onNetworkChanged(@Nullable PressureNetwork network) {}

    /** Узел не принят в сеть: превышен лимит maxBlocksPerNetwork (A.3.5). */
    default void onConnectionRefused() {}
}
