package dev.cpp.pressure.event;

import dev.cpp.CppMod;
import dev.cpp.pressure.core.PressureManager;
import net.minecraft.server.level.ServerLevel;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.level.ChunkEvent;
import net.neoforged.neoforge.event.tick.LevelTickEvent;

/** Подписки на игровую шину: тик менеджера и события чанков (A.2, A.3.4). */
@EventBusSubscriber(modid = CppMod.MODID)
public final class PressureEvents {
    private PressureEvents() {}

    @SubscribeEvent
    public static void onLevelTick(LevelTickEvent.Post event) {
        if (event.getLevel() instanceof ServerLevel level) {
            PressureManager.get(level).tick();
        }
    }

    @SubscribeEvent
    public static void onChunkLoad(ChunkEvent.Load event) {
        if (event.getLevel() instanceof ServerLevel level) {
            PressureManager.get(level).onChunkLoad(event.getChunk().getPos());
        }
    }

    @SubscribeEvent
    public static void onChunkUnload(ChunkEvent.Unload event) {
        if (event.getLevel() instanceof ServerLevel level) {
            PressureManager.get(level).onChunkUnload(event.getChunk().getPos());
        }
    }
}
