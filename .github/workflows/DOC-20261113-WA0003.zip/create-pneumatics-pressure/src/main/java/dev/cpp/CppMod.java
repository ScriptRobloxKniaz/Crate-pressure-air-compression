package dev.cpp;

import com.mojang.logging.LogUtils;
import dev.cpp.network.CppNetwork;
import dev.cpp.pressure.api.PressureCapabilities;
import dev.cpp.registry.ModRegistries;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import org.slf4j.Logger;

/**
 * Create: Pneumatics &amp; Pressure — точка входа.
 * Milestone 1–2: ядро сети давления, трубы, компрессор и двигатель, отладочный манометр.
 */
@Mod(CppMod.MODID)
public final class CppMod {
    public static final String MODID = "cpp";
    public static final Logger LOGGER = LogUtils.getLogger();

    public CppMod(IEventBus modBus) {
        ModRegistries.register(modBus);
        modBus.addListener(CppMod::registerCapabilities);
        modBus.addListener(CppNetwork::registerPayloads);
        LOGGER.info("Create: Pneumatics & Pressure — Milestone 1 (pressure core) loaded");
    }

    private static void registerCapabilities(RegisterCapabilitiesEvent event) {
        PressureCapabilities.register(event, ModRegistries.PRESSURE_NODE.get());
        PressureCapabilities.register(event, ModRegistries.COMPRESSOR.get());
        PressureCapabilities.register(event, ModRegistries.MOTOR.get());
    }

    public static ResourceLocation id(String path) {
        return ResourceLocation.fromNamespaceAndPath(MODID, path);
    }
}
